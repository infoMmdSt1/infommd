import sqlite3
import os
from datetime import datetime
from config import DB_PATH

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE NOT NULL,
            username TEXT,
            first_name TEXT,
            is_vip INTEGER DEFAULT 0,
            is_banned INTEGER DEFAULT 0,
            joined_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS bots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT,
            token TEXT NOT NULL,
            room_id TEXT NOT NULL,
            owner_id TEXT NOT NULL,
            is_active INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            version TEXT DEFAULT '1.0.0',
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bot_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            level TEXT DEFAULT 'INFO',
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (bot_id) REFERENCES bots(id)
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
    """)
    conn.commit()
    conn.close()


# ─── Users ────────────────────────────────────────────────────────────────────

def upsert_user(telegram_id: int, username: str = None, first_name: str = None):
    conn = get_conn()
    conn.execute("""
        INSERT INTO users (telegram_id, username, first_name)
        VALUES (?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET
            username = excluded.username,
            first_name = excluded.first_name
    """, (telegram_id, username, first_name))
    conn.commit()
    conn.close()


def get_user(telegram_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def set_vip(telegram_id: int, status: bool):
    conn = get_conn()
    conn.execute("UPDATE users SET is_vip = ? WHERE telegram_id = ?", (int(status), telegram_id))
    conn.commit()
    conn.close()


def set_banned(telegram_id: int, status: bool):
    conn = get_conn()
    conn.execute("UPDATE users SET is_banned = ? WHERE telegram_id = ?", (int(status), telegram_id))
    conn.commit()
    conn.close()


def get_all_users():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users ORDER BY joined_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_users():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM users").fetchone()
    conn.close()
    return row["n"]


def count_vip():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM users WHERE is_vip=1").fetchone()
    conn.close()
    return row["n"]


def count_today_users():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM users WHERE date(joined_at)=date('now')").fetchone()
    conn.close()
    return row["n"]


# ─── Bots ─────────────────────────────────────────────────────────────────────

def create_bot(user_id: int, token: str, room_id: str, owner_id: str):
    name = f"Bot #{room_id[:6]}"
    conn = get_conn()
    c = conn.execute(
        "INSERT INTO bots (user_id, name, token, room_id, owner_id) VALUES (?,?,?,?,?)",
        (user_id, name, token, room_id, owner_id)
    )
    bot_id = c.lastrowid
    conn.commit()
    conn.close()
    return bot_id


def get_bot(bot_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM bots WHERE id=?", (bot_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_bots(user_db_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM bots WHERE user_id=? ORDER BY created_at DESC", (user_db_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_user_bots(user_db_id: int):
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM bots WHERE user_id=?", (user_db_id,)).fetchone()
    conn.close()
    return row["n"]


def set_bot_active(bot_id: int, active: bool):
    conn = get_conn()
    conn.execute("UPDATE bots SET is_active=? WHERE id=?", (int(active), bot_id))
    conn.commit()
    conn.close()


def update_bot_field(bot_id: int, field: str, value: str):
    allowed = {"token", "room_id", "owner_id", "name"}
    if field not in allowed:
        raise ValueError(f"Field {field} not allowed")
    conn = get_conn()
    conn.execute(f"UPDATE bots SET {field}=? WHERE id=?", (value, bot_id))
    conn.commit()
    conn.close()


def delete_bot(bot_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM logs WHERE bot_id=?", (bot_id,))
    conn.execute("DELETE FROM bots WHERE id=?", (bot_id,))
    conn.commit()
    conn.close()


def get_all_bots():
    conn = get_conn()
    rows = conn.execute("""
        SELECT b.*, u.telegram_id, u.username
        FROM bots b JOIN users u ON b.user_id=u.id
        ORDER BY b.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_active_bots():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM bots WHERE is_active=1").fetchone()
    conn.close()
    return row["n"]


def count_inactive_bots():
    conn = get_conn()
    row = conn.execute("SELECT COUNT(*) as n FROM bots WHERE is_active=0").fetchone()
    conn.close()
    return row["n"]


def search_bots(query: str):
    conn = get_conn()
    rows = conn.execute("""
        SELECT b.*, u.telegram_id, u.username
        FROM bots b JOIN users u ON b.user_id=u.id
        WHERE b.room_id LIKE ? OR b.owner_id LIKE ? OR b.name LIKE ?
        ORDER BY b.created_at DESC LIMIT 20
    """, (f"%{query}%", f"%{query}%", f"%{query}%")).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── Logs ─────────────────────────────────────────────────────────────────────

def add_log(bot_id: int, message: str, level: str = "INFO"):
    conn = get_conn()
    conn.execute("INSERT INTO logs (bot_id, message, level) VALUES (?,?,?)", (bot_id, message, level))
    conn.commit()
    conn.close()


def get_bot_logs(bot_id: int, limit: int = 20):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM logs WHERE bot_id=? ORDER BY created_at DESC LIMIT ?",
        (bot_id, limit)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── Settings ─────────────────────────────────────────────────────────────────

def get_setting(key: str, default: str = ""):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str):
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)", (key, value))
    conn.commit()
    conn.close()
