"""
ربات Highrise — تمام سورس در همین یک فایل (main.py)
====================================================
همه‌ی قابلیت‌ها (دنس‌ها، ترجمه، تلپورت، مدیریت روم، اشتراک‌ها، سیستم پیوی،
تنظیمات اجرا و ...) داخل همین یک فایل جمع شده. هیچ فایل پایتونی یا کانفیگ
دیگه‌ای لازم نیست.

نصب پکیج‌های مورد نیاز (یک بار):
    pip install highrise-bot-sdk deep-translator python-dotenv aiohttp pytz

قبل از اجرا، یک فایل به اسم ".env" کنار همین main.py بساز با این محتوا:
    ROOM_ID=آیدی_روم_تو
    BOT_TOKEN=توکن_ربات_تو
    OWNER_ID=آیدی_کاربری_تو_در_هایرایز   (اختیاری، برای دستورات مالک)

اجرا:
    python main.py

نکته: فایل‌های bot_data.json و suscriptores.json (داده‌های ذخیره‌شده‌ی ربات،
مثل دنس‌های خراب و لیست مشترکین) خودکار توسط همین اسکریپت کنار main.py ساخته
می‌شن؛ نیازی نیست از قبل وجود داشته باشن.
"""

import random
import asyncio
import os
import time
import json
import traceback
from typing import Dict, List

import aiohttp
import pytz
from dotenv import load_dotenv
from deep_translator import GoogleTranslator
from highrise import (
    BaseBot, Position, SessionMetadata, User, CurrencyItem, Item, Reaction,
    AnchorPosition, GetMessagesRequest,
)
from highrise.__main__ import BotDefinition, arun, main

load_dotenv()

# ════════════════════════════════════════════════════════════════════════════
# بخش ۱ — ذخیره‌سازی داده (قبلاً funciones/data_manager.py)
# ════════════════════════════════════════════════════════════════════════════

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_data.json")

_DEFAULT = {
    "admins": [],
    "vips": [],
    "bans": {},
    "mutes": {},
    "named_teles": {},
    "private_teles": {},
    "bot_position": None,
    "broken_dances": {},
}


def load_data() -> dict:
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, encoding="utf-8") as f:
                data = json.load(f)
            for k, v in _DEFAULT.items():
                if k not in data:
                    data[k] = type(v)()
            return data
    except Exception as e:
        print(f"data_manager load error: {e}")
    import copy
    return copy.deepcopy(_DEFAULT)


def save_data(data: dict) -> None:
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"data_manager save error: {e}")



# ════════════════════════════════════════════════════════════════════════════
# بخش ۲ — لوپ امات‌ها و تلپورت اسمی (قبلاً funciones/loop.py و teleport.py)
# ════════════════════════════════════════════════════════════════════════════

xmin, xmax = 13.5, 15.5
ymin, ymax = 2.25, 2.25
zmin, zmax = 16.5, 19.5

emote_id = 'emote-teleporting'

emote_list: list[tuple[str, str]] = [
    ("Abajo",       "idle-wild"),
    ("acostado",    "idle_layingdown"),
    ("Angel",       "emote-snowangel"),
    ("Anime",       "dance-anime"),
    ("Bow",         "emote-bow"),
    ("Boxer",       "emote-boxer"),
    ("Casual",      "idle-dance-casual"),
    ("Charging",    "emote-charging"),
    ("Confusion",   "emote-confused"),
    ("Curtsy",      "emote-curtsy"),
    ("Cute",        "emote-cute"),
    ("Cutey",       "emote-cutey"),
    ("Espada",      "emote-swordfight"),
    ("Explosion",   "emote-headblowup"),
    ("Fashionista", "emote-fashionista"),
    ("float",       "emote-float"),
    ("flotar",      "idle-floating"),
    ("Frog",        "emote-frog"),
    ("Gravity",     "emote-gravity"),
    ("HameHa",      "emote-energyball"),
    ("Hello",       "emote-hello"),
    ("Hyped",       "emote-hyped"),
    ("Ice",         "dance-icecream"),
    ("Jingle",      "dance-jinglebell"),
    ("Kawaii",      "dance-kawai"),
    ("KPop",        "dance-blackpink"),
    ("Maniac",      "emote-maniac"),
    ("Model",       "emote-model"),
    ("Moto",        "emote-sleigh"),
    ("Nervous",     "idle-nervous"),
    ("Ño",          "emote-creepycute"),
    ("Penguin",     "dance-pinguin"),
    ("Pose10",      "emote-pose10"),
    ("Pose3",       "emote-pose3"),
    ("Pose8",       "emote-pose8"),
    ("Punk",        "emote-punkguitar"),
    ("Push",        "dance-employee"),
    ("Regalo",      "emote-gift"),
    ("Russian",     "dance-russian"),
    ("shi",         "emote-shy2"),
    ("Shopping",    "dance-shoppingcart"),
    ("Singing",     "idle_singing"),
    ("Siuu",        "emote-celebrationstep"),
    ("Skating",     "emote-iceskating"),
    ("Snake",       "emote-snake"),
    ("Sorpresa",    "emote-pose6"),
    ("Telekinesis", "emote-telekinesis"),
    ("Thriller",    "dance-creepypuppet"),
    ("TikTok10",    "dance-tiktok10"),
    ("tiktok2",     "dance-tiktok2"),
    ("TikTok4",     "idle-dance-tiktok4"),
    ("tiktok8",     "dance-tiktok8"),
    ("TikTok9",     "dance-tiktok9"),
    ("TimeJump",    "emote-timejump"),
    ("Toilet",      "idle-toilet"),
    ("UwU",         "idle-uwu"),
    ("volar",       "emote-looping"),
    ("Weird",       "dance-weird"),
    ("Wrong",       "dance-wrong"),
    ("Zero",        "emote-astronaut"),
    ("Ditzy",       "emote-pose9"),
    ("Guitar",      "idle-guitar"),
    ("Telepor",     "emote-teleporting"),
    ("Touch",       "dance-touch"),
    ("cohete",      "emote-launch"),
    ("entusiasta",  "idle-enthusiastic"),
    ("Tiktok11",    "dance-tiktok11"),
    ("snowball",    "emote-snowball"),
    ("Paz",         "emote-peace"),
]


async def loop_emote(self: BaseBot, user: User, emote_name: str) -> None:
    try:
        emote_id = next((e[1] for e in emote_list if e[0].lower() == emote_name.lower()), None)
        if emote_id is None:
            return

        await self.highrise.send_whisper(user.id, f"@{user.username} is looping: {emote_name}")

        while True:
            try:
                await self.highrise.send_emote(emote_id, user.id)
                await asyncio.sleep(8.3)

                try:
                    room_users = (await self.highrise.get_room_users()).content
                    user_ids = [u.id for u, _ in room_users]
                    if user.id not in user_ids:
                        break
                except Exception as e:
                    if "Cannot write to closing transport" in str(e):
                        await asyncio.sleep(5)
                        continue
                    continue

            except Exception as e:
                if "Cannot write to closing transport" in str(e):
                    await asyncio.sleep(5)
                    continue
                else:
                    await self.highrise.send_whisper(user.id, f"@{user.username} this emote is not available.")
                    break

    except Exception as e:
        print(f"loop_emote error: {e}")
        try:
            await self.highrise.send_whisper(user.id, "An error occurred. Please try again.")
        except:
            print("Could not send error message")


async def loop(self: BaseBot, user: User, emote_name: str) -> None:
    try:
        emote_id = next((e[1] for e in emote_list if e[0].lower() == emote_name.lower()), None)
        if emote_id is None:
            return

        taskgroup = self.highrise.tg
        task_list: List[asyncio.Task] = list(taskgroup._tasks)

        for task in task_list:
            if task.get_name() == user.username:
                task.cancel()

        task = taskgroup.create_task(loop_emote(self, user, emote_name))
        task.set_name(user.username)

    except Exception as e:
        print(f"loop error: {e}")
        try:
            await self.highrise.chat("An error occurred. Please try again.")
        except:
            print("Could not send error message")


async def stop_loop(self: BaseBot, user: User) -> None:
    try:
        taskgroup = self.highrise.tg
        task_list: List[asyncio.Task] = list(taskgroup._tasks)

        for task in task_list:
            if task.get_name() == user.username:
                task.cancel()
                await self.highrise.send_whisper(user.id, f"@{user.username} emote loop stopped.")
                return

        await self.highrise.send_whisper(user.id, f"@{user.username} you are not looping any emote.")

    except Exception as e:
        print(f"stop_loop error: {e}")
        try:
            await self.highrise.send_whisper(user.id, "An error occurred. Please try again.")
        except:
            print("Could not send error message")


async def emote(self: BaseBot, user: User, message: str) -> None:
    try:
        parts = message.split(" ")
        emote_name = " ".join(parts[1:])
    except:
        await self.highrise.send_whisper(user.id, "Invalid format. Use: all <emote_name>")
        return

    emote_id = ""
    for e in emote_list:
        if e[0].lower() == emote_name.lower():
            emote_id = e[1]
            break

    if emote_id == "":
        await self.highrise.send_whisper(user.id, f"Emote '{emote_name}' not found. Use /emotes to see the list.")
        return

    await self.highrise.send_whisper(user.id, f"Sending {emote_name} to everyone...")

    room_users = (await self.highrise.get_room_users()).content
    for room_user, position in room_users:
        try:
            await self.highrise.send_emote(emote_id, room_user.id)
        except:
            await self.highrise.send_whisper(
                user.id, f"Could not send emote to @{room_user.username}."
            )
        await asyncio.sleep(0.25)  # جلوگیری از rate-limit هنگام ارسال به همه


async def check_position_and_emote(self: BaseBot) -> None:
    while True:
        try:
            room_users = (await self.highrise.get_room_users()).content
            for room_user, position in room_users:
                if isinstance(position, Position):
                    x, y, z = position.x, position.y, position.z
                else:
                    continue
                if (xmin <= x <= xmax) and (ymin <= y <= ymax) and (zmin <= z <= zmax):
                    try:
                        await self.highrise.send_emote(emote_id, room_user.id)
                    except Exception as e:
                        print(f"Emote error for {room_user.username}: {e}")
        except Exception as e:
            print(f"check_position_and_emote error: {e}")
        await asyncio.sleep(9.5)



PREDEFINED_COORDINATES = {
    "paseito1":  Position(0.5, 1.5, 29.5),
    "paseito2":  Position(2.0, 0.0, 4.5),
    "paseito3":  Position(9.5, 11.0, 7.5),
    "paseito4":  Position(0.5, 8.25, 1.5),
    "paseito5":  Position(16.5, 13.5, 19),
    "paseito6":  Position(14.5, 2.25, 17.5),
    "paseito7":  Position(0.5, 6.75, 29.5),
    "paseito8":  Position(16.5, 5, 23.5),
    "paseito9":  Position(11.0, 2.25, 9.0),
    "paseito10": Position(15.5, 12.0, 8.0),
    "paseito11": Position(16.5, 18.5, 2.0),
    "paseitodj": Position(14.5, 18.5, 4.5),
}


async def teleporter(self: BaseBot, user: User, message: str) -> None:
    user_privileges = await self.highrise.get_room_privilege(user.id)
    if not user_privileges.moderator and not self._is_owner(user):
        await self.highrise.send_whisper(user.id, "This feature is for moderators only.")
        return
    try:
        parts = message.strip().split()
        command = parts[0].lower()

        if command not in PREDEFINED_COORDINATES:
            await self.highrise.send_whisper(user.id, f"Unknown location '{command}'.")
            return

        dest = PREDEFINED_COORDINATES[command]

        if len(parts) == 1:
            await self.highrise.teleport(user_id=user.id, dest=dest)
            await self.highrise.send_whisper(user.id, f"Teleported! Enjoy, {user.username} 🚀")

        elif len(parts) == 2 and parts[1].startswith("@"):
            target_name = parts[1][1:].lower()
            room_users = (await self.highrise.get_room_users()).content
            target_id = None

            for room_user, _ in room_users:
                if room_user.username.lower() == target_name:
                    target_id = room_user.id
                    break

            if target_id:
                await self.highrise.teleport(user_id=target_id, dest=dest)
                await self.highrise.send_whisper(user.id, f"@{target_name} has been teleported.")
            else:
                await self.highrise.send_whisper(user.id, f"User @{target_name} not found in room.")
        else:
            await self.highrise.send_whisper(
                user.id, f"Usage: {command}  or  {command} @username"
            )

    except Exception as e:
        await self.highrise.chat(f"Teleport error: {str(e)}")



# ════════════════════════════════════════════════════════════════════════════
# بخش ۳ — سیستم اشتراک/پیوی (قبلاً funciones/subcripciones.py)
# ════════════════════════════════════════════════════════════════════════════

class AdministradorSuscripciones:
    def __init__(self):
        self.archivo_suscriptores = "suscriptores.json"
        self.suscriptores = self.cargar_suscriptores()
        self.esperando_mensaje_admin = {}
        self.esperando_mensaje_masivo = {}
        self.esperando_nuevo_admin = {}
        self.esperando_eliminar_admin = {}

        self.mensaje_manana = (
            "🌅 Good morning!\n\n"
            "Hope you slept well. May this new day bring you joy and happiness!\n\n"
            "Our room is always open for you 🤗\n"
            "https://high.rs/room?id=6694de2ee40b58ae179d8ddf&invite_id=6744912d5edd6cffc721c64c"
        )

        self.mensaje_noche = (
            "🌟 Good evening! Did you visit our room today? 🌟\n\n"
            "Come have fun with us!\n"
            "https://high.rs/room?id=6694de2ee40b58ae179d8ddf&invite_id=6744912d5edd6cffc721c64c"
        )

    def cargar_suscriptores(self) -> Dict:
        estructura_inicial = {
            "suscriptores": {},
            "admins": {
                OWNER_USERNAME: OWNER_ID
            } if OWNER_ID else {}
        }
        try:
            if os.path.exists(self.archivo_suscriptores):
                with open(self.archivo_suscriptores, 'r') as f:
                    data = json.load(f)
                    new_subs = {}
                    for username, value in data.get("suscriptores", {}).items():
                        if username.startswith("Usuario_"):
                            continue
                        if isinstance(value, str):
                            new_subs[username] = {"id": value, "conv_id": None}
                        elif isinstance(value, dict):
                            new_subs[username] = value
                    data["suscriptores"] = new_subs
                    if "admins" not in data:
                        data["admins"] = estructura_inicial["admins"]
                    return data
            return estructura_inicial
        except Exception as e:
            print(f"Error loading subscribers: {e}")
            return estructura_inicial

    def guardar_suscriptores(self) -> None:
        try:
            with open(self.archivo_suscriptores, 'w') as f:
                json.dump(self.suscriptores, f, indent=4)
        except Exception as e:
            print(f"Error saving subscribers: {e}")

    async def obtener_username_webapi(self, user_id: str) -> str:
        try:
            url = f"https://webapi.highrise.game/users/{user_id}"
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data["user"]["username"]
                    return f"User_{user_id}"
        except Exception as e:
            print(f"Error fetching username: {e}")
            return f"User_{user_id}"

    async def mostrar_menu(self, bot, id_usuario: str, id_conversacion: str) -> None:
        menu = (
            "🌟 Subscription System 🌟\n\n"
            "Available commands:\n"
            "  sub    - Subscribe to notifications\n"
            "  unsub  - Unsubscribe\n"
            "  status - Check subscription status\n\n"
            "Subscribe so you never miss an update!"
        )
        await bot.highrise.send_message(id_conversacion, menu)

    async def manejar_mensaje(self, bot, id_usuario: str, id_conversacion: str, mensaje: str) -> None:
        try:
            mensaje = mensaje.lower().strip()
            username = await self.obtener_username_webapi(id_usuario)

            if username in self.suscriptores["suscriptores"]:
                if isinstance(self.suscriptores["suscriptores"][username], str):
                    old_id = self.suscriptores["suscriptores"][username]
                    self.suscriptores["suscriptores"][username] = {"id": old_id, "conv_id": id_conversacion}
                else:
                    self.suscriptores["suscriptores"][username]["conv_id"] = id_conversacion
                self.guardar_suscriptores()

            if mensaje in ("!help", "help", "راهنما"):
                await bot.send_help_dm(id_conversacion)
                return

            if mensaje == "/adm":
                es_admin = (
                    id_usuario in self.suscriptores["admins"].values() or
                    username in self.suscriptores["admins"]
                )
                if es_admin:
                    self.esperando_mensaje_admin[id_usuario] = True
                    await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                else:
                    await bot.highrise.send_message(id_conversacion, "This feature is for admins only.")
                return

            elif self.esperando_mensaje_masivo.get(id_usuario, False):
                if self.esperando_mensaje_masivo.get(id_usuario) == "seleccion":
                    tipo = await self.mensajes_masivos_predefinidos(bot, mensaje)
                    if tipo:
                        await bot.highrise.send_message(id_conversacion, f"✅ {tipo} message sent to all subscribers.")
                    else:
                        await bot.highrise.send_message(id_conversacion, "❌ Invalid option. Choose 1 or 2.")
                else:
                    await self.enviar_mensaje_masivo(bot, mensaje)
                    await bot.highrise.send_message(id_conversacion, "✅ Message sent to all subscribers.")
                self.esperando_mensaje_masivo[id_usuario] = False
                await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                return

            elif self.esperando_mensaje_admin.get(id_usuario, False):
                if mensaje == "msg":
                    await bot.highrise.send_message(id_conversacion, "Enter the message to send to all subscribers:")
                    self.esperando_mensaje_masivo[id_usuario] = True
                elif mensaje == "broadcast":
                    menu_masivo = "Select message to send:\n1 - Good morning message\n2 - Good night message"
                    await bot.highrise.send_message(id_conversacion, menu_masivo)
                    self.esperando_mensaje_masivo[id_usuario] = "seleccion"
                elif self.esperando_mensaje_masivo.get(id_usuario) == "seleccion":
                    tipo = await self.mensajes_masivos_predefinidos(bot, mensaje)
                    if tipo:
                        await bot.highrise.send_message(id_conversacion, f"✅ {tipo} message sent.")
                    else:
                        await bot.highrise.send_message(id_conversacion, "❌ Invalid option.")
                    self.esperando_mensaje_masivo[id_usuario] = False
                    await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                elif mensaje == "listsub":
                    if not self.suscriptores["suscriptores"]:
                        await bot.highrise.send_message(id_conversacion, "No subscribers yet.")
                    else:
                        total = len(self.suscriptores["suscriptores"])
                        text = f"📋 Subscribers ({total}):\n"
                        for uname in self.suscriptores["suscriptores"].keys():
                            text += f"• {uname}\n"
                        await bot.highrise.send_message(id_conversacion, text)
                elif mensaje == "listadm":
                    admins_list = "\n".join([f"• {u}" for u in self.suscriptores["admins"].keys()])
                    await bot.highrise.send_message(id_conversacion, f"📋 Admins:\n{admins_list}")
                elif mensaje == "addadm":
                    if OWNER_ID and id_usuario == OWNER_ID:
                        await bot.highrise.send_message(id_conversacion, "Enter the ID of the new admin:")
                        self.esperando_nuevo_admin[id_usuario] = True
                    else:
                        await bot.highrise.send_message(id_conversacion, f"Only {OWNER_USERNAME} can add admins.")
                elif mensaje == "deladm":
                    if OWNER_ID and id_usuario == OWNER_ID:
                        await bot.highrise.send_message(id_conversacion, "Enter the username of the admin to remove:")
                        self.esperando_eliminar_admin[id_usuario] = True
                    else:
                        await bot.highrise.send_message(id_conversacion, f"Only {OWNER_USERNAME} can remove admins.")
                elif mensaje == "exit":
                    self.esperando_mensaje_admin[id_usuario] = False
                    await bot.highrise.send_message(id_conversacion, "Exited admin panel. 👋")
                elif self.esperando_nuevo_admin.get(id_usuario, False):
                    nuevo_id = mensaje.strip()
                    try:
                        nuevo_username = await self.obtener_username_webapi(nuevo_id)
                        self.suscriptores["admins"][nuevo_username] = nuevo_id
                        self.guardar_suscriptores()
                        await bot.highrise.send_message(id_conversacion, f"✅ {nuevo_username} added as admin.")
                    except:
                        await bot.highrise.send_message(id_conversacion, "❌ Error adding admin. Check the ID.")
                    self.esperando_nuevo_admin[id_usuario] = False
                    await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                elif self.esperando_eliminar_admin.get(id_usuario, False):
                    admin_username = mensaje.strip().lower()
                    found = next((a for a in self.suscriptores["admins"] if a.lower() == admin_username), None)
                    if found:
                        if found.lower() != OWNER_USERNAME.lower():
                            del self.suscriptores["admins"][found]
                            self.guardar_suscriptores()
                            await bot.highrise.send_message(id_conversacion, f"✅ {found} removed from admins.")
                        else:
                            await bot.highrise.send_message(id_conversacion, "❌ Cannot remove the main admin.")
                    else:
                        await bot.highrise.send_message(id_conversacion, "❌ Admin not found.")
                    self.esperando_eliminar_admin[id_usuario] = False
                    await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                else:
                    await self.manejar_mensaje_admin(bot, id_usuario, id_conversacion)
                return

            else:
                if mensaje == "menu":
                    await self.mostrar_menu(bot, id_usuario, id_conversacion)
                elif mensaje == "sub":
                    await self.manejar_suscripcion(bot, id_usuario, id_conversacion)
                elif mensaje == "unsub":
                    await self.manejar_desuscripcion(bot, id_usuario, id_conversacion)
                elif mensaje == "status":
                    await self.mostrar_estado(bot, id_usuario, id_conversacion)
                else:
                    await self.mostrar_menu(bot, id_usuario, id_conversacion)

        except Exception as e:
            print(f"manejar_mensaje error: {e}")

    async def manejar_suscripcion(self, bot, id_usuario: str, id_conversacion: str) -> None:
        try:
            username = await self.obtener_username_webapi(id_usuario)
            if username not in self.suscriptores["suscriptores"]:
                self.suscriptores["suscriptores"][username] = {"id": id_usuario, "conv_id": id_conversacion}
                self.guardar_suscriptores()
                msg = (
                    "You have subscribed successfully! 🎉\n\n"
                    "We're glad to have you with us!\n"
                    "https://high.rs/room?id=6694de2ee40b58ae179d8ddf&invite_id=6744912d5edd6cffc721c64c"
                )
                await bot.highrise.send_message(id_conversacion, msg)
            else:
                await bot.highrise.send_message(id_conversacion, "You are already subscribed! 📫")
        except Exception as e:
            print(f"Subscribe error: {e}")
            await bot.highrise.send_message(id_conversacion, "Error processing subscription. Please try again.")

    async def manejar_desuscripcion(self, bot, id_usuario: str, id_conversacion: str) -> None:
        try:
            username = await self.obtener_username_webapi(id_usuario)
            if username in self.suscriptores["suscriptores"]:
                del self.suscriptores["suscriptores"][username]
                self.guardar_suscriptores()
                await bot.highrise.send_message(id_conversacion, "You have unsubscribed. Hope to see you again! 👋")
            else:
                await bot.highrise.send_message(id_conversacion, "You were not subscribed. 🤔")
        except Exception as e:
            print(f"Unsubscribe error: {e}")
            await bot.highrise.send_message(id_conversacion, "Error processing unsubscription. Please try again.")

    async def mostrar_estado(self, bot, id_usuario: str, id_conversacion: str) -> None:
        try:
            username = await self.obtener_username_webapi(id_usuario)
            if username in self.suscriptores["suscriptores"]:
                await bot.highrise.send_message(id_conversacion, "✅ You are subscribed and will receive all notifications.")
            else:
                await bot.highrise.send_message(id_conversacion, "❌ You are not subscribed. Type 'sub' to subscribe.")
        except Exception as e:
            print(f"Status error: {e}")
            await bot.highrise.send_message(id_conversacion, "Error checking status.")

    async def manejar_mensaje_admin(self, bot, id_usuario: str, id_conversacion: str) -> None:
        if id_usuario in self.suscriptores["admins"].values():
            menu_admin = (
                "🌟 Admin Panel 🌟\n\n"
                "Commands:\n"
                "  msg        - Send custom mass message\n"
                "  broadcast  - Send preset message (morning/night)\n"
                "  listsub    - List all subscribers\n"
                "  listadm    - List all admins\n"
                f"  addadm     - Add new admin ({OWNER_USERNAME} only)\n"
                f"  deladm     - Remove admin ({OWNER_USERNAME} only)\n"
                "  exit       - Exit admin panel\n\n"
                "Type a command:"
            )
            self.esperando_mensaje_admin[id_usuario] = True
            await bot.highrise.send_message(id_conversacion, menu_admin)
        else:
            await bot.highrise.send_message(id_conversacion, "You do not have admin permissions. 🚫")

    async def enviar_mensaje_masivo(self, bot, mensaje: str) -> None:
        for username, datos in self.suscriptores["suscriptores"].items():
            try:
                if datos["conv_id"] is None:
                    print(f"⚠️ No conversation ID for {username}")
                    continue
                if mensaje in [self.mensaje_manana, self.mensaje_noche]:
                    full_msg = mensaje
                else:
                    full_msg = (
                        f"📢 Announcement:\n\n{mensaje}\n\n"
                        "We'd love to see you in our room!\n"
                        "https://high.rs/room?id=6694de2ee40b58ae179d8ddf&invite_id=6744912d5edd6cffc721c64c"
                    )
                await bot.highrise.send_message(datos["conv_id"], full_msg)
                print(f"✅ Message sent to {username}")
            except Exception as e:
                print(f"❌ Error sending to {username}: {e}")

    async def mensajes_masivos_predefinidos(self, bot, opcion: str):
        try:
            if opcion == "1":
                mensaje = self.mensaje_manana
                tipo = "Good morning"
            elif opcion == "2":
                mensaje = self.mensaje_noche
                tipo = "Good night"
            else:
                return None

            for username, datos in self.suscriptores["suscriptores"].items():
                try:
                    if datos["conv_id"] is None:
                        print(f"⚠️ No conversation ID for {username}")
                        continue
                    await bot.highrise.send_message(datos["conv_id"], mensaje)
                    print(f"✅ {tipo} message sent to {username}")
                except Exception as e:
                    print(f"❌ Error sending to {username}: {e}")
            return tipo
        except Exception as e:
            print(f"mensajes_masivos_predefinidos error: {e}")
            return None



# ════════════════════════════════════════════════════════════════════════════
# بخش ۴ — کلاس اصلی ربات (قبلاً main.py)
# ════════════════════════════════════════════════════════════════════════════

# ── مالک ربات ─────────────────────────────────────────────────────────────────
OWNER_USERNAME = "_emi_1390"
OWNER_ID = os.getenv("OWNER_ID", "").strip()

# ── مدت زمان اجرای هر دنس (ثانیه) قبل از تکرار امات ────────────────────────────
# پیش‌فرض 8.3 ثانیه برای اکثر دنس‌هاست؛ بعضی دنس‌ها (مثل Floss) طولانی‌تر از این
# اجرا می‌شن و اگه با همون فاصله‌ی پیش‌فرض دوباره امات فرستاده بشه، وسط دنس قطع
# و انگار از اول شروع می‌شه. اینجا می‌تونیم برای دنس‌های طولانی‌تر فاصله‌ی
# بیشتری تعریف کنیم (کلید = شماره دنس در NUMBERED_DANCES).
DANCE_INTERVAL_OVERRIDES = {
    "248": 13.0,  # Floss — انیمیشن طولانی‌تر از حالت پیش‌فرض داره
}
DEFAULT_DANCE_INTERVAL = 8.3

# ── لیست کامل امات‌ها با شماره (1-257) ────────────────────────────────────────
NUMBERED_DANCES = {
    "1":   ("Ghostfloat",       "dance-ghostfloat"),
    "2":   ("Laidback",         "idle-laidback"),
    "3":   ("Relaxed",          "emote-relaxed"),
    "4":   ("Relaxing",         "emote-relaxing"),
    "5":   ("Cozynap",          "emote-cozynap"),
    "6":   ("Hipshake",         "emote-hipshake"),
    "7":   ("Attentive",        "idle-attentive"),
    "8":   ("Fairyfloat",       "emote-fairyfloat"),
    "9":   ("Fairytwirl",       "emote-fairytwirl"),
    "10":  ("Smooch",           "emote-smooch"),
    "11":  ("Launch",           "emote-launch"),
    "12":  ("Float",            "emote-float"),
    "13":  ("Thriller",         "dance-creepypuppet"),
    "14":  ("Repose",           "emote-repose"),
    "15":  ("Enthused",         "idle-enthusiastic"),
    "16":  ("Saunter",          "emote-saunter"),
    "17":  ("Gravity",          "emote-gravity"),
    "18":  ("Gottago",          "emote-gottago"),
    "19":  ("Astro",            "emote-astronaut"),
    "20":  ("TimeJump",         "emote-timejump"),
    "21":  ("Penguin",          "dance-pinguin"),
    "22":  ("Kawaii",           "dance-kawai"),
    "23":  ("Jingle",           "dance-jinglebell"),
    "24":  ("Skating",          "emote-iceskating"),
    "25":  ("Teleporting",      "emote-teleporting"),
    "26":  ("EnergyBall",       "emote-energyball"),
    "27":  ("Pushit",           "dance-employee"),
    "28":  ("Boxer",            "emote-boxer"),
    "29":  ("Creepycute",       "emote-creepycute"),
    "30":  ("Headblow",         "emote-headblowup"),
    "31":  ("Wrong",            "dance-wrong"),
    "32":  ("Weird",            "dance-weird"),
    "33":  ("UwU",              "idle-uwu"),
    "34":  ("Worm",             "dance-worm"),
    "35":  ("Singalong",        "idle_singing"),
    "36":  ("Model",            "emote-model"),
    "37":  ("Maniac",           "emote-maniac"),
    "38":  ("Snowangel",        "emote-snowangel"),
    "39":  ("Ride",             "emote-ride"),
    "40":  ("Icecream",         "dance-icecream"),
    "41":  ("Surprise",         "emote-pose6"),
    "42":  ("Touch",            "dance-touch"),
    "43":  ("Swordfight",       "emote-swordfight"),
    "44":  ("Airguitar",        "idle-guitar"),
    "45":  ("Zombie",           "dance-zombie"),
    "46":  ("Fashion",          "emote-fashionista"),
    "47":  ("Curtsy",           "emote-curtsy"),
    "48":  ("Cute",             "emote-cute"),
    "49":  ("Telek",            "emote-telekinesis"),
    "50":  ("Russian",          "dance-russian"),
    "51":  ("BlackPink",        "dance-blackpink"),
    "52":  ("Shopping",         "dance-shoppingcart"),
    "53":  ("WopDance",         "dance-wop"),
    "54":  ("ViralGroove",      "dance-viralgroove"),
    "55":  ("Savage",           "dance-savage"),
    "56":  ("Sayso",            "dance-sayso"),
    "57":  ("TikTok",           "dance-tiktok2"),
    "58":  ("Shuffle",          "dance-shuffle"),
    "59":  ("Hot",              "dance-hot"),
    "60":  ("Charge",           "emote-charging"),
    "61":  ("Greedy",           "emote-greedy"),
    "62":  ("Confused",         "emote-confused"),
    "63":  ("Punkguitar",       "emote-punkguitar"),
    "64":  ("Bashful",          "emote-bashful"),
    "65":  ("Scritchy",         "emote-scritchy"),
    "66":  ("Nervous",          "idle-nervous"),
    "67":  ("Hyped",            "emote-hyped"),
    "68":  ("Fishing",          "emote-fishing"),
    "69":  ("Frog",             "emote-frog"),
    "70":  ("Siu",              "emote-celebrationstep"),
    "71":  ("Snowball",         "emote-snowball"),
    "72":  ("Bow",              "emote-bow"),
    "73":  ("TheWave",          "emote-thewave"),
    "74":  ("Tired",            "emote-tired"),
    "75":  ("Pennywise",        "dance-pennywise"),
    "76":  ("Superpose",        "emote-superpose"),
    "77":  ("Pose8",            "emote-pose8"),
    "78":  ("Laugh",            "emote-laugh"),
    "79":  ("Kiss",             "emote-smooch"),
    "80":  ("Hello",            "emote-hello"),
    "81":  ("Gift",             "emote-gift"),
    "82":  ("Arabesque",        "emote-arabesque"),
    "83":  ("Thumbsup",         "emote-thumbsup"),
    "84":  ("Cursing",          "emote-cursing"),
    "85":  ("Celebrate",        "emote-celebrate"),
    "86":  ("Macarena",         "dance-macarena"),
    "87":  ("Sit",              "idle-toilet"),
    "88":  ("Gag",              "emote-gag"),
    "89":  ("Pose7",            "emote-pose7"),
    "90":  ("Deny",             "emote-deny"),
    "91":  ("Casual",           "idle-dance-casual"),
    "92":  ("Pose1",            "emote-pose1"),
    "93":  ("Pose3",            "emote-pose3"),
    "94":  ("Pose5",            "emote-pose5"),
    "95":  ("Cutey",            "emote-cutey"),
    "96":  ("ThatsRight",       "emote-thatsright"),
    "97":  ("Pose9",            "emote-pose9"),
    "98":  ("Angry",            "emote-angry"),
    "99":  ("MiningMine",       "emote-miningmine"),
    "100": ("MiningSuccess",    "emote-miningsuccess"),
    "101": ("FishingPull",      "emote-fishingpull"),
    "102": ("FishingSmall",     "emote-fishingpullsmall"),
    "103": ("FishingCast",      "emote-fishingcast"),
    "104": ("Shrink",           "emote-shrink"),
    "105": ("Posh",             "emote-posh"),
    "106": ("Ponder",           "emote-ponder"),
    "107": ("Hero",             "emote-hero"),
    "108": ("Stargaze",         "emote-stargaze"),
    "109": ("Disappointed",     "emote-receivedisappointed"),
    "110": ("Sleepy",           "emote-sleepy"),
    "111": ("Annoyed",          "emote-annoyed"),
    "112": ("Aerobics",         "dance-aerobics"),
    "113": ("Irritated",        "emote-irritated"),
    "114": ("Icanfly",          "emote-icanfly"),
    "115": ("Theatrical",       "emote-theatrical"),
    "116": ("Tapdance",         "dance-tapdance"),
    "117": ("Superrun",         "emote-superrun"),
    "118": ("Superpunch",       "emote-superpunch"),
    "119": ("Sumo",             "emote-sumo"),
    "120": ("Splits",           "emote-splits"),
    "121": ("Handshake",        "emote-handshake"),
    "122": ("Ropepull",         "emote-ropepull"),
    "123": ("Roll",             "emote-roll"),
    "124": ("Rofl",             "emote-rofl"),
    "125": ("Robot",            "emote-robot"),
    "126": ("Rainbow",          "emote-rainbow"),
    "127": ("Proposing",        "emote-proposing"),
    "128": ("Peekaboo",         "emote-peekaboo"),
    "129": ("Peace",            "emote-peace"),
    "130": ("Panic",            "emote-panic"),
    "131": ("Ninjarun",         "emote-ninjarun"),
    "132": ("NightFever",       "dance-nightfever"),
    "133": ("Monsterfail",      "emote-monsterfail"),
    "134": ("Levelup",          "emote-levelup"),
    "135": ("Superkick",        "emote-superkick"),
    "136": ("Judochop",         "emote-judochop"),
    "137": ("Hugyourself",      "emote-hugyourself"),
    "138": ("Harlemshake",      "dance-harlemshake"),
    "139": ("Moonwalk",         "dance-moonwalk"),
    "140": ("Gangnam",          "dance-gangnam"),
    "141": ("Faint",            "emote-faint"),
    "142": ("Clumsy",           "emote-clumsy"),
    "143": ("Fail",             "emote-fail"),
    "144": ("Exasperated",      "emote-exasperated"),
    "145": ("Elbowbump",        "emote-elbowbump"),
    "146": ("Disco",            "dance-disco"),
    "147": ("Blastoff",         "emote-blastoff"),
    "148": ("Deathdrop",        "emote-deathdrop"),
    "149": ("Collapse",         "emote-collapse"),
    "150": ("Revive",           "emote-revive"),
    "151": ("Dab",              "emote-dab"),
    "152": ("Bunnyhop",         "emote-bunnyhop"),
    "153": ("Boo",              "emote-boo"),
    "154": ("Baseball",         "emote-baseball"),
    "155": ("Fallapart",        "emote-fallapart"),
    "156": ("Point",            "emote-point"),
    "157": ("Sneeze",           "emote-sneeze"),
    "158": ("Smirk",            "emote-smirk"),
    "159": ("Sick",             "emote-sick"),
    "160": ("Gasp",             "emote-gasp"),
    "161": ("Punch",            "emote-punch"),
    "162": ("Pray",             "emote-pray"),
    "163": ("Stinky",           "emote-stinky"),
    "164": ("Naughty",          "emote-naughty"),
    "165": ("Mindblown",        "emote-mindblown"),
    "166": ("Lying",            "emote-lying"),
    "167": ("Halo",             "emote-halo"),
    "168": ("Hadoken",          "emote-hadoken"),
    "169": ("Giveup",           "emote-giveup"),
    "170": ("Stunned",          "emote-stunned"),
    "171": ("Clapping",         "emote-clapping"),
    "172": ("Arrogance",        "emote-arrogance"),
    "173": ("Voguehands",       "emote-voguehands"),
    "174": ("Smoothwalk",       "emote-smoothwalk"),
    "175": ("Ringonit",         "dance-ringonit"),
    "176": ("GoShopping",       "emote-goingshopping"),
    "177": ("Robotic",          "emote-robotic"),
    "178": ("Metal",            "emote-metal"),
    "179": ("Handsup",          "emote-handsup"),
    "180": ("Duckwalk",         "emote-duckwalk"),
    "181": ("Attention",        "emote-attention"),
    "182": ("Loveflutter",      "emote-loveflutter"),
    "183": ("Hearthands",       "emote-hearthands"),
    "184": ("Partnerheart",     "emote-partnerheart"),
    "185": ("Hug",              "emote-hug"),
    "186": ("Eyeroll",          "emote-eyeroll"),
    "187": ("Embarrassed",      "emote-embarrassed"),
    "188": ("Wiggledance",      "dance-wiggledance"),
    "189": ("Puppet",           "emote-puppet"),
    "190": ("Fighter",          "emote-fighter"),
    "191": ("Rage",             "emote-rage"),
    "192": ("Slap",             "emote-slap"),
    "193": ("Guitar",           "idle-guitar"),
    "194": ("Aerobics2",        "dance-aerobics2"),
    "195": ("Cheerleader",      "emote-cheerleader"),
    "196": ("Fruity",           "dance-fruity"),
    "197": ("OrangeJustice",    "dance-orangejustice"),
    "198": ("TikTok14",         "dance-tiktok14"),
    "199": ("Zombie2",          "dance-zombie2"),
    "200": ("Crying",           "emote-crying"),
    "201": ("Ghosts",           "emote-ghosts"),
    "202": ("Cold",             "emote-cold"),
    "203": ("Confused2",        "emote-confused2"),
    "204": ("Cutesalute",       "emote-cutesalute"),
    "205": ("ExasperatedB",     "emote-exasperatedb"),
    "206": ("Handstand",        "emote-handstand"),
    "207": ("Happy",            "emote-happy"),
    "208": ("Howl",             "emote-howl"),
    "209": ("Jetpack",          "emote-jetpack"),
    "210": ("JumpB",            "emote-jumpb"),
    "211": ("Laugh2",           "emote-laugh2"),
    "212": ("Riflethrow",       "emote-riflethrow"),
    "213": ("Sad",              "emote-sad"),
    "214": ("Salute",           "emote-salute"),
    "215": ("Shy",              "emote-shy"),
    "216": ("Suckthumb",        "emote-suckthumb"),
    "217": ("SwingCelebrate",   "emote-swingcelebrate"),
    "218": ("SwingNet",         "emote-swingnet"),
    "219": ("Think",            "emote-think"),
    "220": ("Trampoline",       "emote-trampoline"),
    "221": ("Headbobbing",      "emote-headbobbing"),
    "222": ("TikTok7",          "dance-tiktok7"),
    "223": ("Howl2",            "emote-howl2"),
    "224": ("Chilling",         "emote-chilling"),
    "225": ("Sad2",             "emote-sad2"),
    "226": ("Shy2",             "emote-shy2"),
    "227": ("Tapdance2",        "dance-tapdance2"),
    "228": ("Tired2",           "emote-tired2"),
    "229": ("Pouty",            "emote-pouty"),
    "230": ("Zombie3",          "dance-zombie3"),
    "231": ("MiningFail",       "emote-miningfail"),
    "232": ("SakuraStep",       "dance-sakurastep"),
    "233": ("BlossomReach",     "emote-blossomreach"),
    "234": ("Treepose",         "emote-treepose"),
    "235": ("Warrior2",         "emote-warrior2"),
    "236": ("PetalPerch",       "emote-petalperch"),
    "237": ("MidnightPoise",    "emote-midnightpoise"),
    "238": ("MidnightStrut",    "emote-midnightstrut"),
    "239": ("MidnightAllur",    "emote-midnightallur"),
    "240": ("StormGroove",      "dance-stormgroove"),
    "241": ("StormMood",        "emote-stormmood"),
    "242": ("ChaosCutie",       "emote-chaoscutie"),
    "243": ("RebelDarling",     "emote-rebeldarling"),
    "244": ("SweetTease",       "emote-sweettease"),
    "245": ("SweetStrike",      "emote-sweetstrike"),
    "246": ("SweetFix",         "emote-sweetfix"),
    "247": ("SweetLure",        "emote-sweetlure"),
    "248": ("Floss",            "dance-floss"),
    "249": ("Rest",             "emote-rest"),
}

# ── اسم اتاق (اینجا تغییر بده) ────────────────────────────────────────────────
ROOM_NAME = "اتاق ما"

# ── جستجو بر اساس اسم ─────────────────────────────────────────────────────────
DANCE_BY_NAME = {
    name.lower(): (num, emote_id)
    for num, (name, emote_id) in NUMBERED_DANCES.items()
}


class Bot(BaseBot):
    GOODBYE_MESSAGES = [
        "خداحافظ! 🌴",
        "مراقب خودت باش، بعداً می‌بینمت! 🍃",
        "ممنون که اومدی! 🌟",
        "تا دفعه بعد! 🌺",
        "روز خوبی داشته باشی! 🍂",
    ]

    SUPPORTED_LANGUAGES = {
        'fa': 'فارسی',
        'es': 'اسپانیایی',
        'en': 'انگلیسی',
        'fr': 'فرانسوی',
        'de': 'آلمانی',
        'it': 'ایتالیایی',
        'pt': 'پرتغالی',
        'ja': 'ژاپنی',
        'zh': 'چینی',
        'ar': 'عربی',
        'hi': 'هندی',
        'tr': 'ترکی',
        'ru': 'روسی',
        'ko': 'کره‌ای',
        'vi': 'ویتنامی',
        'id': 'اندونزیایی',
        'th': 'تایلندی',
        'ms': 'مالایی',
        'nl': 'هلندی',
        'pl': 'لهستانی',
    }

    def __init__(self):
        super().__init__()
        self.room_users = []
        self.user_conversations = {}
        self.active_translation_users = {}
        self.bot_id = None
        self.admin_suscripciones = AdministradorSuscripciones()
        self._wel_text = (
            f"خوش اومدی به {ROOM_NAME} 💞 "
            "برای دنس زدن تایپ کن 1 تا 249 و برای لغو بگو stop "
            "بهترین لحظه هارو برات آرزو میکنم ✨"
        )
        self._wel_interval = 1
        self._broadcast_task = None
        # ── داده‌های پایدار (admins, vips, bans, mutes, teles …) ──────────────
        self._data = load_data()
        # ── اسپم ─────────────────────────────────────────────────────────────
        self._spam_task = None
        self._spam_interval = 1.0
        # ── فریز / فالو / هارت ───────────────────────────────────────────────
        self._freeze_tasks: dict = {}
        self._follow_task = None
        self._follow_target_id = None
        self._heart_on_join: bool = False
        # ── موقعیت ذخیره‌شده ربات ─────────────────────────────────────────────
        self._bot_saved_pos: list | None = self._data.get("bot_position")
        # ── دنس عددی در حال اجرا برای هر کاربر (user.id → number) ─────────────
        # تا وقتی دنس فعلی تموم نشده، تایپ دوباره‌ی همون دنس آن را ری‌استارت نمی‌کند
        self._active_dance: dict = {}

    async def on_start(self, session_metadata: SessionMetadata) -> None:
        print("ربات روشن شد")
        self.bot_id = session_metadata.user_id
        await self.highrise.teleport(session_metadata.user_id, Position(0.5, 8.25, 2.5, "FrontRight"))
        await self.highrise.chat("ربات آنلاین شد! برای دیدن دستورات !help بنویس 🤖")
        asyncio.create_task(self.repeat_emote())
        asyncio.create_task(self.send_information())
        self._broadcast_task = asyncio.create_task(self.broadcast_welcome())
        asyncio.create_task(self.advertise_loop())
        asyncio.create_task(self.ban_checker_loop())
        asyncio.create_task(self.mute_checker_loop())

    async def on_chat(self, user: User, message: str) -> None:
        if self._is_banned(user):
            return
        if self._is_muted(user):
            return
        message_lower = message.lower().strip()

        try:
            # ── متوقف کردن دنس ──────────────────────────────────────────────
            if message_lower == "stop":
                await stop_loop(self, user)
                self._active_dance.pop(user.id, None)
                return

            # ── دنس عددی یا اسمی ────────────────────────────────────────────
            if message_lower in NUMBERED_DANCES:
                name, emote_id = NUMBERED_DANCES[message_lower]
                await self._start_numbered_dance(user, message_lower, name, emote_id)
                return

            if message_lower in DANCE_BY_NAME:
                num, emote_id = DANCE_BY_NAME[message_lower]
                name = NUMBERED_DANCES[num][0]
                await self._start_numbered_dance(user, num, name, emote_id)
                return

            # ── دستورات ترجمه ────────────────────────────────────────────────
            if message_lower.startswith("!text"):
                await self.activate_translation(user, message_lower)
                return
            elif message_lower == "!stop":
                await self.deactivate_translation(user)
                return
            elif user.id in self.active_translation_users:
                await self.translate_message(user, message)
                return

            # ── لوپ امات با اسم ─────────────────────────────────────────────
            await loop(self, user, message_lower)

            # ── دستورات اصلی ─────────────────────────────────────────────────
            if message_lower == "tour!":
                await self.start_tour(user)
            elif message_lower.startswith("wallet"):
                privileges = await self.highrise.get_room_privilege(user.id)
                if not self._is_owner(user) and not (privileges.moderator or privileges.designer):
                    await self.highrise.chat("این دستور فقط برای مدیران است.")
                    return
                await self.handle_wallet_command(user)
            elif message_lower.startswith("users"):
                privileges = await self.highrise.get_room_privilege(user.id)
                if not self._is_owner(user) and not (privileges.moderator or privileges.designer):
                    await self.highrise.chat("این دستور فقط برای مدیران است.")
                    return
                await self.list_users()
            elif message_lower.startswith("all "):
                privileges = await self.highrise.get_room_privilege(user.id)
                if not self._is_owner(user) and not (privileges.moderator or privileges.designer):
                    await self.highrise.chat("این دستور فقط برای مدیران است.")
                    return
                await self.handle_all_command(user, message_lower)
            elif message_lower.startswith("!tipme "):
                if self._is_owner(user):
                    await self.handle_tipme_command(user, message)
            elif any(message_lower.startswith(cmd) for cmd in ["paseito"]):
                await teleporter(self, user, message_lower)
            elif message_lower.startswith(("رقص ", "پرواز ", "سلام ", "مبارزه ")):
                await self.handle_interaction_command(user, message_lower)
            elif message_lower.startswith("!"):
                await self.command_handler(user, message_lower, message)
            else:
                await self._try_named_tele(user, message_lower)

        except Exception as e:
            await self.highrise.chat(f"خطا: {e}")

    async def _start_numbered_dance(self, user: User, number: str, name: str, emote_id: str) -> None:
        """دنس عددی را شروع می‌کند.

        اگر همین دنس همین الان برای این کاربر در حال اجراست، دوباره تایپ کردنش
        نادیده گرفته می‌شود تا دنس وسط اجرا قطع/ری‌استارت نشود — فقط وقتی دنس
        واقعاً تموم شد (کاربر «stop» بگه یا از روم بره) دوباره قابل اجراست.
        """
        if self._active_dance.get(user.id) == number:
            return
        broken = self._data.get("broken_dances", {})
        if number in broken:
            await self.highrise.send_whisper(
                user.id,
                f"❌ دنس {name} ({number}) طبق آخرین بررسی «!checkdances» در دسترس نیست."
            )
            return
        try:
            taskgroup = self.highrise.tg
            task_list = list(taskgroup._tasks)
            for task in task_list:
                if task.get_name() == user.username:
                    task.cancel()

            self._active_dance[user.id] = number

            async def dance_loop():
                try:
                    while True:
                        try:
                            await self.highrise.send_emote(emote_id, user.id)
                            # اولین اجرا موفق بود — به کاربر اطلاع بده
                            await self.highrise.send_whisper(
                                user.id, f"💃 دنس {name} ({number}) شروع شد! برای توقف «stop» بنویس."
                            )
                            break
                        except Exception as e:
                            err = str(e)
                            if "Cannot write to closing transport" in err or "connection" in err.lower():
                                await asyncio.sleep(5)
                                continue
                            # امات در دسترس نیست یا خطای دیگه
                            await self.highrise.send_whisper(
                                user.id,
                                f"❌ دنس {name} ({number}) در دسترس نیست یا امات نامعتبره.\n"
                                f"ID: {emote_id}"
                            )
                            return

                    # حلقه اصلی — هر بار فقط بعد از پایان واقعی چرخه‌ی دنس دوباره اجرا می‌شود
                    interval = DANCE_INTERVAL_OVERRIDES.get(number, DEFAULT_DANCE_INTERVAL)
                    while True:
                        try:
                            await asyncio.sleep(interval)
                            room_users = (await self.highrise.get_room_users()).content
                            if user.id not in [u.id for u, _ in room_users]:
                                break
                            await self.highrise.send_emote(emote_id, user.id)
                        except Exception as e:
                            err = str(e)
                            if "Cannot write to closing transport" in err or "connection" in err.lower():
                                await asyncio.sleep(5)
                                continue
                            await self.highrise.send_whisper(
                                user.id, f"⚠️ دنس {name} متوقف شد: {err[:80]}"
                            )
                            break
                finally:
                    # وقتی دنس واقعاً تموم شد (یا کنسل شد)، وضعیتش رو آزاد کن
                    if self._active_dance.get(user.id) == number:
                        self._active_dance.pop(user.id, None)

            task = taskgroup.create_task(dance_loop())
            task.set_name(user.username)

        except Exception as e:
            self._active_dance.pop(user.id, None)
            print(f"خطا در دنس عددی: {e}")

    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool) -> None:
        try:
            response = await self.highrise.get_messages(conversation_id)
            if not response.messages:
                return
            message = response.messages[0].content
            room_users = await self.highrise.get_room_users()
            user_info = next((u for u, _ in room_users.content if u.id == user_id), None)
            print(f"پیام خصوصی از {user_info.username if user_info else user_id}: {message}")
            await self.admin_suscripciones.manejar_mensaje(self, user_id, conversation_id, message)
        except Exception as e:
            print(f"خطا در on_message: {e}")
            import traceback
            traceback.print_exc()

    async def on_user_join(self, user: User, position) -> None:
        try:
            print(f"{user.username} وارد شد.")
            msg = (
                f"سلام {user.username} عزیزم خوش اومدی به {ROOM_NAME} "
                f"امیدوارم خوش بگذره بهت💞 "
                f"برای دنس زدن تایپ کن 1 تا 249 و برای لغو بگو stop "
                f"بهترین لحظه هارو برات آرزو میکنم ✨"
            )
            await self.highrise.chat(msg)
            if self._heart_on_join:
                try:
                    await self.highrise.react(reaction="heart", user_id=user.id)
                except Exception:
                    pass
        except Exception as e:
            print(f"خطا در on_user_join: {e}")

    async def on_user_leave(self, user: User) -> None:
        while True:
            try:
                goodbye = random.choice(self.GOODBYE_MESSAGES)
                await self.highrise.chat(f"@{user.username} رفت 👋 {goodbye}")
                break
            except Exception as e:
                if "connection with ID:" in str(e):
                    await asyncio.sleep(5)
                    continue
                else:
                    print(f"خطا در on_user_leave: {e}")
                    break

    async def list_users(self) -> None:
        room_users = (await self.highrise.get_room_users()).content
        for user, position in room_users:
            if hasattr(position, 'x'):
                print(f"کاربر: {user.username} | ID: {user.id} | موقعیت: x={position.x}, y={position.y}, z={position.z}")
            else:
                print(f"کاربر: {user.username} | ID: {user.id} | موقعیت: Anchor")

    async def broadcast_welcome(self) -> None:
        """ارسال دوره‌ای پیام خوش‌آمدگویی با اینتروال تنظیم‌شده"""
        while True:
            try:
                await asyncio.sleep(self._wel_interval)
                await self.highrise.chat(self._wel_text)
            except Exception:
                await asyncio.sleep(5)

    async def repeat_emote(self) -> None:
        """دنس خود ربات - Floss"""
        while True:
            try:
                await asyncio.sleep(5.55)
                await self.highrise.send_emote("dance-floss")
            except Exception:
                try:
                    await self.highrise.send_emote("dance-weird")
                except Exception:
                    pass
                await asyncio.sleep(5)
                continue

    async def handle_wallet_command(self, user: User) -> None:
        wallet = (await self.highrise.get_wallet()).content
        await self.highrise.send_whisper(user.id, f"💰 موجودی ربات: {wallet[0].amount} {wallet[0].type}")

    async def handle_all_command(self, user: User, message: str) -> None:
        await emote(self, user, message)

    async def handle_interaction_command(self, user: User, message: str) -> None:
        interaction_commands = {
            "رقص":    ("dance-weird",      "dance-kawai",    "با هم می‌رقصند! 💃"),
            "سلام":   ("emote-bow",        "emote-curtsy",   "احوال‌پرسی کردند! 👋"),
            "پرواز":  ("emote-astronaut",  "emote-looping",  "با هم پرواز می‌کنند! 🚀"),
            "مبارزه": ("emote-boxer",      "emote-boxer",    "با هم می‌جنگند! 🥊"),
        }
        try:
            parts = message.split()
            if len(parts) < 2 or not parts[1].startswith("@"):
                await self.highrise.chat("نحوه استفاده: دستور @نام‌کاربری")
                return
            target_name = parts[1][1:].lower()
            room_users = await self.highrise.get_room_users()
            target_user = next((u for u, _ in room_users.content if u.username.lower() == target_name), None)
            if not target_user:
                await self.highrise.chat(f"کاربر {target_name} در اتاق پیدا نشد.")
                return
            command = next((cmd for cmd in interaction_commands if message.startswith(cmd)), None)
            if command:
                emote1, emote2, text = interaction_commands[command]
                await self.highrise.chat(f"@{user.username} و @{target_user.username} {text}")
                await self.highrise.send_emote(emote1, user.id)
                await self.highrise.send_emote(emote2, target_user.id)
        except Exception as e:
            await self.highrise.chat(f"خطا: {e}")

    async def activate_translation(self, user: User, message_lower: str) -> None:
        parts = message_lower.split()
        if len(parts) == 3:
            src, dst = parts[1], parts[2]
            if src in self.SUPPORTED_LANGUAGES and dst in self.SUPPORTED_LANGUAGES:
                self.active_translation_users[user.id] = {'source': src, 'target': dst}
                await self.highrise.chat(
                    f"✅ ترجمه برای @{user.username} فعال شد: "
                    f"{self.SUPPORTED_LANGUAGES[src]} ← → {self.SUPPORTED_LANGUAGES[dst]}"
                )
            else:
                await self.highrise.chat(f"@{user.username} زبان پشتیبانی نمی‌شود. /languages را ببین.")
        else:
            await self.highrise.chat(f"@{user.username} نحوه استفاده: !text fa en")

    async def deactivate_translation(self, user: User) -> None:
        if user.id in self.active_translation_users:
            del self.active_translation_users[user.id]
            await self.highrise.chat(f"@{user.username} ترجمه غیرفعال شد.")
        else:
            await self.highrise.chat(f"@{user.username} ترجمه فعال نبود.")

    async def translate_message(self, user: User, message: str) -> None:
        try:
            cfg = self.active_translation_users[user.id]
            translator = GoogleTranslator(source=cfg['source'], target=cfg['target'])
            translated = translator.translate(message)
            await self.highrise.chat(f"@{user.username} گفت: \"{translated}\"")
        except Exception as e:
            await self.highrise.chat(f"خطا در ترجمه: {str(e)}")

    async def start_tour(self, user: User) -> None:
        try:
            tour_data = [
                {"position": Position(0.5, 1.5, 29.5),   "emote": "idle-enthusiastic"},
                {"position": Position(2.0, 0.0, 4.5),    "emote": "emote-confused"},
                {"position": Position(9.5, 11.0, 7.5),   "emote": "emote-pose9"},
                {"position": Position(0.5, 8.25, 1.5),   "emote": "emote-looping"},
                {"position": Position(16.5, 13.5, 19),   "emote": "emote-astronaut"},
                {"position": Position(0.5, 6.75, 29.5),  "emote": "emote-pose8"},
                {"position": Position(14.5, 2.25, 17.5), "emote": "emote-teleporting"},
                {"position": Position(13.5, 17.75, 4.0), "emote": "idle-enthusiastic"},
                {"position": Position(16.5, 5, 23.5),    "emote": "emote-hyped"},
                {"position": Position(12, 1, 10),        "emote": "idle-enthusiastic"},
            ]
            await self.highrise.send_whisper(user.id, "🚀 تور اتاق شروع شد!")
            for stop in tour_data:
                try:
                    await self.highrise.teleport(user.id, stop["position"])
                    await self.highrise.send_emote(stop["emote"], user.id)
                    await asyncio.sleep(7)
                except Exception as e:
                    print(f"خطا در توقف تور: {e}")
                    continue
            await self.highrise.send_whisper(user.id, "🎉 تور تمام شد!")
        except Exception as e:
            print(f"خطا در تور: {e}")
            await self.highrise.send_whisper(user.id, "متأسفم، خطایی در تور رخ داد.")

    async def handle_tipme_command(self, user: User, message: str) -> None:
        try:
            amount = message.split()[1]
            if not amount.isdigit():
                await self.highrise.send_whisper(user.id, "یک مقدار معتبر وارد کن.")
                return
            amount = int(amount)
            if amount < 1:
                await self.highrise.send_whisper(user.id, "مقدار باید بیشتر از ۰ باشد.")
                return
            try:
                await self.highrise.tip_user(user.id, amount)
                await self.highrise.send_whisper(user.id, f"!{amount} سکه ارسال شد!")
            except Exception:
                await self.highrise.send_whisper(user.id, "پرداخت انجام نشد. موجودی کافی نیست.")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")

    async def send_information(self) -> None:
        while True:
            try:
                await asyncio.sleep(300)
                messages = [
                    "📖 برای دیدن همه دستورات /help بنویس!",
                    "💃 برای دنس، یه عدد از ۱ تا ۲۴۹ تایپ کن!",
                    "🛑 برای متوقف کردن دنس «stop» بنویس!",
                    "🌍 برای ترجمه متن، !text fa en بنویس!",
                    "🚀 برای تور اتاق «tour!» بنویس!",
                    "📩 برای اشتراک در اعلان‌ها، پیام خصوصی به ربات بده!",
                ]
                await self.highrise.chat(random.choice(messages))
            except Exception as e:
                if "connection with ID:" in str(e):
                    await asyncio.sleep(5)
                continue

    async def handle_setitem(self, user: User, message: str) -> None:
        """کپی لباس یک کاربر روی ربات — فقط ادمین"""
        if not self._is_owner(user):
            await self.highrise.send_whisper(user.id, "این دستور فقط برای ادمین است.")
            return
        parts = message.strip().split()
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !setitem @نام‌کاربری  یا  !setitem userId")
            return
        target = parts[1].lstrip("@")
        user_id = None
        try:
            room_users = (await self.highrise.get_room_users()).content
            for ru, _ in room_users:
                if ru.username.lower() == target.lower() or ru.id == target:
                    user_id = ru.id
                    break
        except Exception:
            pass
        if not user_id:
            user_id = target
        try:
            outfit_resp = await self.highrise.get_user_outfit(user_id)
            if not outfit_resp or not outfit_resp.outfit:
                await self.highrise.send_whisper(user.id, "نتونستم لباس این کاربر رو بگیرم.")
                return
            await self.highrise.set_outfit(outfit_resp.outfit)
            await self.highrise.send_whisper(user.id, "✅ لباس با موفقیت روی ربات اعمال شد!")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا در دریافت لباس: {e}")

    # ════════════════════════════════════════════════════════════════════════════
    # ── ابزارهای کمکی ──────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    def _is_owner(self, user: User) -> bool:
        if OWNER_ID and user.id == OWNER_ID:
            return True
        return user.username.lower() == OWNER_USERNAME.lower()

    def _is_admin(self, user: User) -> bool:
        return self._is_owner(user) or user.id in self._data.get("admins", [])

    def _is_vip(self, user: User) -> bool:
        return user.id in self._data.get("vips", [])

    def _is_staff(self, user: User) -> bool:
        return self._is_admin(user) or self._is_vip(user)

    def _is_banned(self, user: User) -> bool:
        bans = self._data.get("bans", {})
        if user.id not in bans:
            return False
        until = bans[user.id].get("until", 0)
        if until == -1:
            return True
        return time.time() < until

    def _is_muted(self, user: User) -> bool:
        mutes = self._data.get("mutes", {})
        if user.id not in mutes:
            return False
        until = mutes[user.id].get("until", 0)
        if until == -1:
            return True
        return time.time() < until

    async def _resolve_user(self, target: str):
        """برگرداندن User از @نام یا id — None اگر پیدا نشد"""
        name = target.lstrip("@").lower()
        try:
            room_users = (await self.highrise.get_room_users()).content
            for ru, _ in room_users:
                if ru.username.lower() == name or ru.id == target:
                    return ru
        except Exception:
            pass
        return None

    def _parse_minutes(self, s: str) -> int | None:
        try:
            return int(s)
        except ValueError:
            return None

    def _save(self):
        save_data(self._data)

    # ════════════════════════════════════════════════════════════════════════════
    # ── تسک‌های پس‌زمینه ────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def advertise_loop(self) -> None:
        """هر ۵ دقیقه تبلیغ ربات‌ساز"""
        while True:
            try:
                await asyncio.sleep(300)
                await self.highrise.chat(
                    "🤖 آیا ربات هوشمند می‌خوای؟ "
                    "برای خرید این ربات با تمام امکانات به "
                    "@@CreatorHrBot پیام بده! 💎"
                )
            except Exception:
                await asyncio.sleep(10)

    async def ban_checker_loop(self) -> None:
        while True:
            await asyncio.sleep(60)
            try:
                bans = self._data.get("bans", {})
                expired = [uid for uid, v in bans.items()
                           if v.get("until", -1) != -1 and time.time() >= v["until"]]
                for uid in expired:
                    try:
                        await self.highrise.moderate_room(uid, "unban", None)
                    except Exception:
                        pass
                    del bans[uid]
                if expired:
                    self._save()
            except Exception:
                pass

    async def mute_checker_loop(self) -> None:
        while True:
            await asyncio.sleep(30)
            try:
                mutes = self._data.get("mutes", {})
                expired = [uid for uid, v in mutes.items()
                           if v.get("until", -1) != -1 and time.time() >= v["until"]]
                for uid in expired:
                    del mutes[uid]
                if expired:
                    self._save()
            except Exception:
                pass

    async def _do_spam(self, count: int, text: str) -> None:
        for _ in range(count):
            if asyncio.current_task().cancelled():
                break
            try:
                await self.highrise.chat(text)
            except Exception:
                pass
            await asyncio.sleep(self._spam_interval)

    async def _freeze_user(self, user_id: str, pos: Position) -> None:
        while True:
            try:
                await asyncio.sleep(1.5)
                if asyncio.current_task().cancelled():
                    break
                await self.highrise.teleport(user_id, pos)
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(2)

    async def _follow_user(self, target_id: str) -> None:
        while True:
            try:
                if asyncio.current_task().cancelled():
                    break
                room_users = (await self.highrise.get_room_users()).content
                for ru, pos in room_users:
                    if ru.id == target_id:
                        if isinstance(pos, Position):
                            await self.highrise.teleport(self.bot_id, pos)
                        break
                await asyncio.sleep(3)
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(5)

    # ════════════════════════════════════════════════════════════════════════════
    # ── تلپورت ──────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_tp(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !tp @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        room_users = (await self.highrise.get_room_users()).content
        pos = next((p for ru, p in room_users if ru.id == target.id), None)
        if not isinstance(pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت کاربر قابل خواندن نیست.")
            return
        await self.highrise.teleport(user.id, pos)
        await self.highrise.send_whisper(user.id, f"✅ به پیش {target.username} تلپورت شدی!")

    async def _cmd_gettp(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !gettp @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        room_users = (await self.highrise.get_room_users()).content
        my_pos = next((p for ru, p in room_users if ru.id == user.id), None)
        if not isinstance(my_pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت خودت خوانده نشد.")
            return
        await self.highrise.teleport(target.id, my_pos)
        await self.highrise.send_whisper(user.id, f"✅ {target.username} پیشت آورده شد!")

    async def _cmd_tpall(self, user: User) -> None:
        room_users = (await self.highrise.get_room_users()).content
        my_pos = next((p for ru, p in room_users if ru.id == user.id), None)
        if not isinstance(my_pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت خودت خوانده نشد.")
            return
        count = 0
        for ru, _ in room_users:
            if ru.id == user.id or ru.id == self.bot_id:
                continue
            try:
                await self.highrise.teleport(ru.id, my_pos)
                count += 1
            except Exception:
                pass
        await self.highrise.send_whisper(user.id, f"✅ {count} نفر پیشت تلپورت شدن!")

    # ════════════════════════════════════════════════════════════════════════════
    # ── تیپ گلد ─────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_tip(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !tip @نام مقدار")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        amount = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 1
        try:
            await self.highrise.tip_user(target.id, amount)
            await self.highrise.send_whisper(user.id, f"✅ {amount} گلد به {target.username} تیپ شد!")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا در تیپ: {e}")

    async def _cmd_tipall(self, user: User, parts: list) -> None:
        if len(parts) < 2 or not parts[1].isdigit():
            await self.highrise.send_whisper(user.id, "استفاده: !tipall مقدار")
            return
        amount = int(parts[1])
        room_users = (await self.highrise.get_room_users()).content
        sent = 0
        for ru, _ in room_users:
            if ru.id == self.bot_id:
                continue
            try:
                await self.highrise.tip_user(ru.id, amount)
                sent += 1
            except Exception:
                pass
        await self.highrise.send_whisper(user.id, f"✅ {amount} گلد به {sent} نفر تیپ شد!")

    async def _cmd_tiptime(self, user: User, parts: list) -> None:
        if len(parts) < 3:
            await self.highrise.send_whisper(user.id, "استفاده: !tiptime دقیقه مقدارگلد")
            return
        mins = self._parse_minutes(parts[1])
        if mins is None or not parts[2].isdigit():
            await self.highrise.send_whisper(user.id, "فرمت: !tiptime دقیقه مقدارگلد")
            return
        amount = int(parts[2])
        await self.highrise.send_whisper(user.id, f"⏳ بعد از {mins} دقیقه به همه {amount} گلد تیپ می‌شه.")

        async def _delayed():
            await asyncio.sleep(mins * 60)
            room_users = (await self.highrise.get_room_users()).content
            for ru, _ in room_users:
                if ru.id == self.bot_id:
                    continue
                try:
                    await self.highrise.tip_user(ru.id, amount)
                except Exception:
                    pass
            await self.highrise.chat(f"🎁 {amount} گلد به همه تیپ شد!")

        asyncio.create_task(_delayed())

    async def _cmd_tiprandom(self, user: User, parts: list) -> None:
        if len(parts) < 3:
            await self.highrise.send_whisper(user.id, "استفاده: !tiprandom مقدارگلد تعدادنفر")
            return
        if not parts[1].isdigit() or not parts[2].isdigit():
            await self.highrise.send_whisper(user.id, "هر دو عدد باید عدد باشن.")
            return
        amount, num = int(parts[1]), int(parts[2])
        room_users = (await self.highrise.get_room_users()).content
        pool = [ru for ru, _ in room_users if ru.id != self.bot_id]
        chosen = random.sample(pool, min(num, len(pool)))
        sent = 0
        for ru in chosen:
            try:
                await self.highrise.tip_user(ru.id, amount)
                sent += 1
            except Exception:
                pass
        names = ", ".join(f"@{ru.username}" for ru in chosen)
        await self.highrise.send_whisper(user.id, f"✅ {amount} گلد به {sent} نفر رندوم: {names}")

    # ════════════════════════════════════════════════════════════════════════════
    # ── تلپورت اسمی (همه کاربران) ───────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_addtele(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !addtele نام")
            return
        name = parts[1].lower()
        room_users = (await self.highrise.get_room_users()).content
        my_pos = next((p for ru, p in room_users if ru.id == user.id), None)
        if not isinstance(my_pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت تو خوانده نشد. یه جا وایسا.")
            return
        self._data["named_teles"][name] = [my_pos.x, my_pos.y, my_pos.z]
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ تلپورت «{name}» ذخیره شد!")

    async def _cmd_untele(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !untele نام")
            return
        name = parts[1].lower()
        if name not in self._data["named_teles"]:
            await self.highrise.send_whisper(user.id, "این تلپورت وجود نداره.")
            return
        del self._data["named_teles"][name]
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ تلپورت «{name}» حذف شد.")

    async def _cmd_listtele(self, user: User) -> None:
        teles = self._data.get("named_teles", {})
        if not teles:
            await self.highrise.send_whisper(user.id, "هنوز تلپورتی ثبت نشده.")
            return
        lines = ["┌─── 📍 لیست تلپورت‌های عمومی ───┐"]
        for name, coords in teles.items():
            lines.append(f"│ {name}")
        lines.append("└─────────────────────────────────┘")
        await self.highrise.send_whisper(user.id, "\n".join(lines))

    async def _try_named_tele(self, user: User, message_lower: str) -> bool:
        """اگر پیام اسم یه تلپورت عمومی بود، تلپورت کن. True برگردون."""
        teles = self._data.get("named_teles", {})
        if message_lower not in teles:
            return False
        coords = teles[message_lower]
        try:
            await self.highrise.teleport(user.id, Position(coords[0], coords[1], coords[2]))
            await self.highrise.send_whisper(user.id, f"🚀 به «{message_lower}» تلپورت شدی!")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")
        return True

    # ════════════════════════════════════════════════════════════════════════════
    # ── اسپم ─────────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_spam(self, user: User, parts: list, original: str) -> None:
        if len(parts) < 3:
            await self.highrise.send_whisper(user.id, "استفاده: !spam تعداد متن")
            return
        if not parts[1].isdigit():
            await self.highrise.send_whisper(user.id, "تعداد باید عدد باشه.")
            return
        count = int(parts[1])
        text = original.split(None, 2)[2] if len(original.split(None, 2)) > 2 else parts[2]
        if self._spam_task and not self._spam_task.done():
            self._spam_task.cancel()
        self._spam_task = asyncio.create_task(self._do_spam(count, text))
        await self.highrise.send_whisper(user.id, f"✅ اسپم {count} تا شروع شد.")

    async def _cmd_stopspam(self, user: User) -> None:
        if self._spam_task and not self._spam_task.done():
            self._spam_task.cancel()
            await self.highrise.send_whisper(user.id, "✅ اسپم متوقف شد.")
        else:
            await self.highrise.send_whisper(user.id, "اسپمی در حال اجرا نیست.")

    async def _cmd_timespam(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !timespam ثانیه (0.05 تا 5)")
            return
        try:
            secs = float(parts[1])
        except ValueError:
            await self.highrise.send_whisper(user.id, "عدد معتبر بده.")
            return
        secs = max(0.05, min(5.0, secs))
        self._spam_interval = secs
        await self.highrise.send_whisper(user.id, f"✅ فاصله اسپم: {secs} ثانیه")

    # ════════════════════════════════════════════════════════════════════════════
    # ── بن / کیک / آنبن ──────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_ban(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !ban @نام دقیقه  (0=دائمی)")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر در اتاق پیدا نشد.")
            return
        if self._is_owner(target):
            await self.highrise.send_whisper(user.id, "مالک قابل بن نیست.")
            return
        mins = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        until = -1 if mins == 0 else time.time() + mins * 60
        self._data["bans"][target.id] = {"until": until, "username": target.username}
        self._save()
        try:
            mod_time = None if mins == 0 else mins * 60
            await self.highrise.moderate_room(target.id, "ban", mod_time)
        except Exception:
            pass
        label = "دائمی" if mins == 0 else f"{mins} دقیقه"
        await self.highrise.send_whisper(user.id, f"🔨 {target.username} بن شد ({label}).")

    async def _cmd_kick(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !kick @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if self._is_owner(target):
            await self.highrise.send_whisper(user.id, "مالک قابل کیک نیست.")
            return
        try:
            await self.highrise.moderate_room(target.id, "kick", None)
            await self.highrise.send_whisper(user.id, f"👢 {target.username} کیک شد.")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")

    async def _cmd_unban(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !unban @نام")
            return
        name = parts[1].lstrip("@").lower()
        uid = next((uid for uid, v in self._data["bans"].items()
                    if v.get("username", "").lower() == name), None)
        if not uid:
            await self.highrise.send_whisper(user.id, "این کاربر در لیست بن نیست.")
            return
        try:
            await self.highrise.moderate_room(uid, "unban", None)
        except Exception:
            pass
        del self._data["bans"][uid]
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ {name} از بن خارج شد.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── مدیریت ادمین و وی‌آی‌پی ──────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_addadmin(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !addadmin @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if target.id not in self._data["admins"]:
            self._data["admins"].append(target.id)
            self._save()
        await self.highrise.send_whisper(user.id, f"✅ {target.username} ادمین شد.")

    async def _cmd_unadmin(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !unadmin @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if target.id in self._data["admins"]:
            self._data["admins"].remove(target.id)
            self._save()
        await self.highrise.send_whisper(user.id, f"✅ {target.username} از ادمینی خارج شد.")

    async def _cmd_addvip(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !addvip @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if target.id not in self._data["vips"]:
            self._data["vips"].append(target.id)
            self._save()
        await self.highrise.send_whisper(user.id, f"✅ {target.username} وی‌آی‌پی شد.")

    async def _cmd_unvip(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !unvip @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if target.id in self._data["vips"]:
            self._data["vips"].remove(target.id)
            self._save()
        await self.highrise.send_whisper(user.id, f"✅ {target.username} از وی‌آی‌پی خارج شد.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── تلپورت ویژه (ادمین/وی‌آی‌پی/مالک) ──────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_crtele(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !crtele نام")
            return
        name = parts[1].lower()
        room_users = (await self.highrise.get_room_users()).content
        my_pos = next((p for ru, p in room_users if ru.id == user.id), None)
        if not isinstance(my_pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت تو خوانده نشد.")
            return
        self._data["private_teles"][name] = [my_pos.x, my_pos.y, my_pos.z]
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ تلپورت ویژه «{name}» ذخیره شد!")

    async def _cmd_uncrtele(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !uncrtele نام")
            return
        name = parts[1].lower()
        if name in self._data["private_teles"]:
            del self._data["private_teles"][name]
            self._save()
            await self.highrise.send_whisper(user.id, f"✅ تلپورت ویژه «{name}» حذف شد.")
        else:
            await self.highrise.send_whisper(user.id, "این تلپورت ویژه وجود نداره.")

    async def _cmd_teles(self, user: User) -> None:
        teles = self._data.get("private_teles", {})
        if not teles:
            await self.highrise.send_whisper(user.id, "هنوز تلپورت ویژه‌ای ثبت نشده.")
            return
        lines = ["┌─── 🔐 تلپورت‌های ویژه ──────────┐"]
        for name in teles:
            lines.append(f"│ !go {name}")
        lines.append("└──────────────────────────────────┘")
        await self.highrise.send_whisper(user.id, "\n".join(lines))

    async def _cmd_go_private(self, user: User, parts: list) -> None:
        """!go نام — استفاده از تلپورت ویژه توسط ادمین/وی‌آی‌پی/مالک"""
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !go نام")
            return
        name = parts[1].lower()
        coords = self._data.get("private_teles", {}).get(name)
        if not coords:
            await self.highrise.send_whisper(user.id, "این تلپورت ویژه وجود نداره.")
            return
        await self.highrise.teleport(user.id, Position(coords[0], coords[1], coords[2]))
        await self.highrise.send_whisper(user.id, f"🔐 به «{name}» تلپورت شدی!")

    # ════════════════════════════════════════════════════════════════════════════
    # ── ری‌اکشن ──────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_heart(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !heart @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        try:
            await self.highrise.react(reaction="heart", user_id=target.id)
            await self.highrise.send_whisper(user.id, f"💖 قلب به {target.username} فرستاده شد!")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")

    async def _cmd_heartall(self, user: User) -> None:
        room_users = (await self.highrise.get_room_users()).content
        count = 0
        for ru, _ in room_users:
            if ru.id == self.bot_id:
                continue
            try:
                await self.highrise.react(reaction="heart", user_id=ru.id)
                count += 1
            except Exception:
                pass
            await asyncio.sleep(0.3)
        await self.highrise.send_whisper(user.id, f"💖 به {count} نفر قلب فرستاده شد!")

    # ════════════════════════════════════════════════════════════════════════════
    # ── تبلیغ به سابسکرایبرها ────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_tab(self, user: User) -> None:
        subs = self.admin_suscripciones.suscriptores.get("suscriptores", {})
        room_id = os.getenv("ROOM_ID", "")
        link = f"https://high.rs/room?id={room_id}" if room_id else "اتاق ما"
        msg = (
            f"🏠 به اتاق ما بیا!\n"
            f"مالک: @{OWNER_USERNAME}\n"
            f"{link}"
        )
        sent = 0
        for username, datos in subs.items():
            try:
                conv_id = datos.get("conv_id") if isinstance(datos, dict) else None
                if conv_id:
                    await self.highrise.send_message(conv_id, msg)
                    sent += 1
            except Exception:
                pass
        await self.highrise.send_whisper(user.id, f"✅ تبلیغ به {sent} نفر ارسال شد.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── کنترل ربات ───────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_getbot(self, user: User, parts: list) -> None:
        if len(parts) >= 2:
            target = await self._resolve_user(parts[1])
            if not target:
                await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
                return
            dest_user_id = target.id
        else:
            dest_user_id = user.id
        room_users = (await self.highrise.get_room_users()).content
        pos = next((p for ru, p in room_users if ru.id == dest_user_id), None)
        if not isinstance(pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت مقصد خوانده نشد.")
            return
        await self.highrise.teleport(self.bot_id, pos)
        await self.highrise.send_whisper(user.id, "✅ ربات تلپورت شد!")

    async def _cmd_setbot(self, user: User) -> None:
        room_users = (await self.highrise.get_room_users()).content
        pos = next((p for ru, p in room_users if ru.id == self.bot_id), None)
        if not isinstance(pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت ربات خوانده نشد.")
            return
        self._bot_saved_pos = [pos.x, pos.y, pos.z]
        self._data["bot_position"] = self._bot_saved_pos
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ موقعیت ربات ذخیره شد: ({pos.x}, {pos.y}, {pos.z})")

    # ════════════════════════════════════════════════════════════════════════════
    # ── میوت ─────────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_mute(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !mute @نام دقیقه (0=دائمی)")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if self._is_owner(target):
            await self.highrise.send_whisper(user.id, "مالک قابل میوت نیست.")
            return
        mins = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        until = -1 if mins == 0 else time.time() + mins * 60
        self._data["mutes"][target.id] = {"until": until, "username": target.username}
        self._save()
        label = "دائمی" if mins == 0 else f"{mins} دقیقه"
        await self.highrise.send_whisper(user.id, f"🔇 {target.username} میوت شد ({label}).")

    async def _cmd_unmute(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !unmute @نام")
            return
        name = parts[1].lstrip("@").lower()
        uid = next((uid for uid, v in self._data["mutes"].items()
                    if v.get("username", "").lower() == name), None)
        if not uid:
            await self.highrise.send_whisper(user.id, "این کاربر میوت نیست.")
            return
        del self._data["mutes"][uid]
        self._save()
        await self.highrise.send_whisper(user.id, f"✅ {name} از میوت خارج شد.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── فریز ─────────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_frez(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !frez @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if self._is_owner(target):
            await self.highrise.send_whisper(user.id, "مالک قابل فریز نیست.")
            return
        room_users = (await self.highrise.get_room_users()).content
        pos = next((p for ru, p in room_users if ru.id == target.id), None)
        if not isinstance(pos, Position):
            await self.highrise.send_whisper(user.id, "موقعیت کاربر خوانده نشد.")
            return
        if target.id in self._freeze_tasks:
            self._freeze_tasks[target.id].cancel()
        task = asyncio.create_task(self._freeze_user(target.id, pos))
        self._freeze_tasks[target.id] = task
        await self.highrise.send_whisper(user.id, f"🧊 {target.username} فریز شد.")

    async def _cmd_unfrez(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !unfrez @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        task = self._freeze_tasks.pop(target.id, None)
        if task:
            task.cancel()
            await self.highrise.send_whisper(user.id, f"✅ {target.username} از فریز خارج شد.")
        else:
            await self.highrise.send_whisper(user.id, "این کاربر فریز نیست.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── فالو ──────────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_follow(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !follow @نام")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if self._follow_task and not self._follow_task.done():
            self._follow_task.cancel()
        self._follow_target_id = target.id
        self._follow_task = asyncio.create_task(self._follow_user(target.id))
        await self.highrise.send_whisper(user.id, f"🏃 ربات دنبال {target.username} میره.")

    async def _cmd_unfollow(self, user: User) -> None:
        if self._follow_task and not self._follow_task.done():
            self._follow_task.cancel()
            self._follow_target_id = None
            await self.highrise.send_whisper(user.id, "✅ ربات دیگه دنبال کسی نمیره.")
        else:
            await self.highrise.send_whisper(user.id, "ربات الان دنبال کسی نیست.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── پینگ ──────────────────────────────────────════════════════════════════════
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_ping(self, user: User) -> None:
        t0 = time.time()
        await self.highrise.get_room_users()
        ms = int((time.time() - t0) * 1000)
        await self.highrise.send_whisper(user.id, f"🏓 پینگ ربات: {ms}ms")

    # ════════════════════════════════════════════════════════════════════════════
    # ── مشت ──────────────────────────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_punch(self, user: User, parts: list) -> None:
        if len(parts) < 2:
            await self.highrise.send_whisper(user.id, "استفاده: !punch @نام یا !punch آیدی")
            return
        target = await self._resolve_user(parts[1])
        if not target:
            await self.highrise.send_whisper(user.id, "کاربر پیدا نشد.")
            return
        if target.id == user.id:
            await self.highrise.send_whisper(user.id, "نمی‌تونی خودتو مشت بزنی! 😅")
            return
        try:
            await self.highrise.chat(f"👊 {user.username} یه مشت محکم زد به {target.username}!")
            await self.highrise.send_emote("emote-punch", user.id)
            await self.highrise.send_emote("emote-clumsy", target.id)
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")

    # ════════════════════════════════════════════════════════════════════════════
    # ── بررسی دنس‌ها (فقط مالک) ──────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════════════════════════

    async def _cmd_checkdances(self, user: User) -> None:
        """تمام دنس‌های شماره‌دار را روی خودِ ربات تست می‌کند (بدون مزاحمت برای کاربران)
        و نتیجه را ذخیره می‌کند تا دنس‌های خراب دیگر برای کاربران اجرا نشوند."""
        await self.highrise.send_whisper(
            user.id, f"🔍 شروع بررسی {len(NUMBERED_DANCES)} دنس... چند دقیقه طول می‌کشه، صبر کن."
        )
        broken: dict = {}
        working = 0
        for number, (name, emote_id) in NUMBERED_DANCES.items():
            try:
                await self.highrise.send_emote(emote_id, self.bot_id)
                working += 1
            except Exception as e:
                broken[number] = {"name": name, "emote_id": emote_id, "error": str(e)[:120]}
            await asyncio.sleep(1.2)

        self._data["broken_dances"] = broken
        self._save()

        await self.highrise.send_whisper(
            user.id, f"✅ بررسی تموم شد: {working} دنس سالم، {len(broken)} دنس خراب."
        )
        if broken:
            items = list(broken.items())
            chunk_size = 15
            for i in range(0, len(items), chunk_size):
                lines = ["┌─── ❌ دنس‌های خراب ───┐"]
                for number, info in items[i:i + chunk_size]:
                    lines.append(f"│ {number} — {info['name']} ({info['emote_id']})")
                lines.append("└──────────────────────┘")
                await self.highrise.send_whisper(user.id, "\n".join(lines))
                await asyncio.sleep(0.3)
            await self.highrise.send_whisper(
                user.id, "این دنس‌ها تا !checkdances بعدی غیرفعال می‌مونن تا کاربرا خطا نگیرن."
            )
        else:
            await self.highrise.send_whisper(user.id, "🎉 همه دنس‌ها سالم هستن!")

    async def _cmd_resetdances(self, user: User) -> None:
        self._data["broken_dances"] = {}
        self._save()
        await self.highrise.send_whisper(user.id, "✅ لیست دنس‌های خراب پاک شد؛ همه دوباره فعال شدن.")

    # ════════════════════════════════════════════════════════════════════════════
    # ── تلپورت اسمی در on_chat ──────────────────────────────────════════════════
    # ════════════════════════════════════════════════════════════════════════════

    async def command_handler(self, user: User, message: str, original: str = "") -> None:
        try:
            parts = message[1:].split()
            if not parts:
                return
            cmd = parts[0].lower()

            # ── دستورات عمومی (همه کاربران) ─────────────────────────────────
            if cmd == 'help':
                await self.show_help(user); return
            if cmd == 'info':
                await self.show_info(user); return
            if cmd == 'rules':
                await self.show_rules(user); return
            if cmd == 'languages':
                await self.show_languages(user); return
            if cmd == 'emotes':
                await self.show_emotes(user); return
            if cmd == 'dances':
                page = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 1
                await self.show_dances(user, page); return
            if cmd == 'punch':
                await self._cmd_punch(user, parts); return

            # ── دستور welspm/timewel — فقط ادمین ────────────────────────────
            if cmd == 'welspm':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین می‌تونه."); return
                text = (original or message)[len("!welspm"):].strip()
                if not text:
                    await self.highrise.send_whisper(user.id, "متن رو بعد از !welspm بنویس."); return
                self._wel_text = text
                await self.highrise.send_whisper(user.id, f"✅ متن پیام تنظیم شد."); return

            if cmd == 'timewel':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین می‌تونه."); return
                if len(parts) < 2 or not parts[1].isdigit():
                    await self.highrise.send_whisper(user.id, "استفاده: !timewel ثانیه"); return
                self._wel_interval = max(1, int(parts[1]))
                await self.highrise.send_whisper(user.id, f"✅ هر {self._wel_interval} ثانیه یه‌بار."); return

            # ── همه دستورات بعدی فقط ادمین یا وی‌آی‌پی ─────────────────────
            if not self._is_staff(user):
                await self.highrise.send_whisper(user.id, "⛔ این دستور فقط برای ادمین و وی‌آی‌پی است.")
                return

            # ── بخش تلپورت ──────────────────────────────────────────────────
            if cmd == 'tp':
                await self._cmd_tp(user, parts); return
            if cmd == 'gettp':
                await self._cmd_gettp(user, parts); return
            if cmd == 'tpall':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tpall(user); return

            # ── بخش تیپ گلد — فقط ادمین ────────────────────────────────────
            if cmd == 'tip':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tip(user, parts); return
            if cmd == 'tipall':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tipall(user, parts); return
            if cmd == 'tiptime':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tiptime(user, parts); return
            if cmd == 'tiprandom':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tiprandom(user, parts); return

            # ── تلپورت اسمی (عمومی) — فقط ادمین برای ساخت ─────────────────
            if cmd == 'addtele':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_addtele(user, parts); return
            if cmd == 'untele':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_untele(user, parts); return
            if cmd == 'listtele':
                await self._cmd_listtele(user); return

            # ── اسپم ────────────────────────────────────────────────────────
            if cmd == 'spam':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_spam(user, parts, original or message); return
            if cmd == 'stopspam':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_stopspam(user); return
            if cmd == 'timespam':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_timespam(user, parts); return

            # ── بن / کیک / آنبن ─────────────────────────────────────────────
            if cmd == 'ban':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_ban(user, parts); return
            if cmd == 'kick':
                await self._cmd_kick(user, parts); return
            if cmd == 'unban':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_unban(user, parts); return

            # ── مدیریت ادمین و وی‌آی‌پی — فقط مالک ────────────────────────
            if cmd in ('addadmin', 'unadmin', 'addvip', 'unvip'):
                if not self._is_owner(user):
                    await self.highrise.send_whisper(user.id, "فقط مالک می‌تونه."); return
                if cmd == 'addadmin':
                    await self._cmd_addadmin(user, parts)
                elif cmd == 'unadmin':
                    await self._cmd_unadmin(user, parts)
                elif cmd == 'addvip':
                    await self._cmd_addvip(user, parts)
                elif cmd == 'unvip':
                    await self._cmd_unvip(user, parts)
                return

            # ── تلپورت ویژه (ادمین/وی‌آی‌پی/مالک) ──────────────────────────
            if cmd == 'crtele':
                await self._cmd_crtele(user, parts); return
            if cmd == 'uncrtele':
                await self._cmd_uncrtele(user, parts); return
            if cmd == 'teles':
                await self._cmd_teles(user); return
            if cmd == 'go':
                await self._cmd_go_private(user, parts); return

            # ── ری‌اکشن ──────────────────────────────────────────────────────
            if cmd == 'heart':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_heart(user, parts); return
            if cmd == 'heartall':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_heartall(user); return
            if cmd == 'hon':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                self._heart_on_join = True
                await self.highrise.send_whisper(user.id, "💖 قلب برای ورودی‌ها روشن شد."); return
            if cmd == 'hoff':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                self._heart_on_join = False
                await self.highrise.send_whisper(user.id, "💔 قلب برای ورودی‌ها خاموش شد."); return

            # ── تبلیغ به سابسکرایبرها ───────────────────────────────────────
            if cmd == 'tab':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_tab(user); return

            # ── کنترل ربات ──────────────────────────────────────────────────
            if cmd == 'getbot':
                await self._cmd_getbot(user, parts); return
            if cmd == 'setbot':
                await self._cmd_setbot(user); return

            # ── setitem ─────────────────────────────────────────────────────
            if cmd == 'setitem':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self.handle_setitem(user, message); return

            # ── میوت ────────────────────────────────────────────────────────
            if cmd == 'mute':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_mute(user, parts); return
            if cmd == 'unmute':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_unmute(user, parts); return

            # ── فریز ────────────────────────────────────────────────────────
            if cmd == 'frez':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_frez(user, parts); return
            if cmd == 'unfrez':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_unfrez(user, parts); return

            # ── فالو ─────────────────────────────────────────────────────────
            if cmd == 'follow':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_follow(user, parts); return
            if cmd == 'unfollow':
                if not self._is_admin(user):
                    await self.highrise.send_whisper(user.id, "فقط ادمین."); return
                await self._cmd_unfollow(user); return

            # ── پینگ — فقط مالک ─────────────────────────────────────────────
            if cmd == 'ping':
                if not self._is_owner(user):
                    await self.highrise.send_whisper(user.id, "فقط مالک."); return
                await self._cmd_ping(user); return

            # ── بررسی سلامت دنس‌ها — فقط مالک ────────────────────────────────
            if cmd == 'checkdances':
                if not self._is_owner(user):
                    await self.highrise.send_whisper(user.id, "فقط مالک."); return
                await self._cmd_checkdances(user); return
            if cmd == 'resetdances':
                if not self._is_owner(user):
                    await self.highrise.send_whisper(user.id, "فقط مالک."); return
                await self._cmd_resetdances(user); return

            await self.highrise.send_whisper(user.id, "دستور ناشناخته. !help را بنویس.")
        except Exception as e:
            await self.highrise.send_whisper(user.id, f"خطا: {e}")

    # ── !help ──────────────────────────────────────────────────────────────────
    async def show_help(self, user: User) -> None:
        for i, text in enumerate(self._help_texts()):
            if i > 0:
                await asyncio.sleep(0.3)
            await self.highrise.send_whisper(user.id, text)

    def _help_texts(self) -> list:
        """متن راهنما را به‌صورت لیستی از چند پیام برمی‌گرداند (مشترک بین چت اتاق و پیوی)."""
        return [
            (
                "┌─── 📋 دستورات عمومی ───────────────────┐\n"
                "│ !help / !info / !rules / !dances\n"
                "│ !text fa en  ← ترجمه   │ !stop ← قطع\n"
                "│ 1 تا 249     ← دنس     │ stop  ← قطع\n"
                "│ رقص/پرواز/سلام/مبارزه @کاربر\n"
                "│ !punch @کاربر  ← یه مشت به کسی بزن\n"
                "│ tour!  ← تور اتاق\n"
                "│ نام‌تلپورت  ← تلپورت به مکان اسمی\n"
                "└────────────────────────────────────────┘"
            ),
            (
                "┌─── 🔐 دستورات ادمین/وی‌آی‌پی ─────────────┐\n"
                "│ تلپورت:\n"
                "│  !tp @نام    !gettp @نام    !tpall\n"
                "│ تیپ گلد:\n"
                "│  !tip @نام مقدار\n"
                "│  !tipall مقدار\n"
                "│  !tiptime دقیقه مقدار\n"
                "│  !tiprandom مقدار تعداد\n"
                "│ تلپورت اسمی:\n"
                "│  !addtele نام  !untele نام  !listtele\n"
                "│ اسپم:\n"
                "│  !spam تعداد متن  !stopspam  !timespam ث\n"
                "│ بن/کیک:\n"
                "│  !ban @نام دقیقه  !kick @نام  !unban @نام\n"
                "│ میوت:  !mute @نام دقیقه  !unmute @نام\n"
                "│ فریز:  !frez @نام  !unfrez @نام\n"
                "│ فالو:  !follow @نام  !unfollow\n"
                "│ ری‌اکشن:\n"
                "│  !heart @نام  !heartall  !hon  !hoff\n"
                "│ ربات:  !getbot [@نام]  !setbot\n"
                "│ تبلیغ: !tab\n"
                "│ پیام‌دوره‌ای: !welspm متن  !timewel ث\n"
                "│ لباس:  !setitem @نام\n"
                "└────────────────────────────────────────┘"
            ),
            (
                "┌─── 👑 دستورات مالک ────────────────────┐\n"
                "│  !addadmin @نام   !unadmin @نام\n"
                "│  !addvip @نام     !unvip @نام\n"
                "│  !crtele نام  !uncrtele نام  !teles\n"
                "│  !go نام  ← تلپورت ویژه ادمین/وی‌آی‌پی\n"
                "│  !ping  ← پینگ ربات\n"
                "│  !checkdances  ← تست سلامت همه دنس‌ها\n"
                "│  !resetdances  ← فعال‌سازی دوباره همه دنس‌ها\n"
                "└────────────────────────────────────────┘"
            ),
        ]

    async def send_help_dm(self, conversation_id: str) -> None:
        """متن راهنما را در پیام خصوصی (پیوی) ارسال می‌کند."""
        for i, text in enumerate(self._help_texts()):
            if i > 0:
                await asyncio.sleep(0.3)
            await self.highrise.send_message(conversation_id, text)

    async def show_dances(self, user: User, page: int = 1) -> None:
        page_size = 25
        items = list(NUMBERED_DANCES.items())
        total = len(items)
        total_pages = (total + page_size - 1) // page_size

        if page < 1 or page > total_pages:
            await self.highrise.send_whisper(user.id, f"صفحه نامعتبر. از ۱ تا {total_pages} انتخاب کن.")
            return

        start = (page - 1) * page_size
        chunk = items[start:start + page_size]

        lines = [f"┌─── 💃 لیست امات‌ها (صفحه {page}/{total_pages}) ──┐"]
        for num, (name, _) in chunk:
            lines.append(f"│ {num:>3} ← {name}")
        lines.append(f"│ stop ← متوقف کردن")
        lines.append(f"│ !dances {page+1} ← صفحه بعد" if page < total_pages else "│ ─── آخرین صفحه ───")
        lines.append("└────────────────────────────┘")

        await self.highrise.send_whisper(user.id, "\n".join(lines))

    async def show_info(self, user: User) -> None:
        info = (
            "┌─── 🤖 اطلاعات ربات ───────┐\n"
            "│ نام: ربات کمک و سرگرمی\n"
            "│ نسخه: ۱.۰\n"
            f"│ سازنده: {OWNER_USERNAME}\n"
            "│ هدف: کمک و شادتر کردن اتاق\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, info)

    async def show_rules(self, user: User) -> None:
        rules = (
            "┌─── 📜 قوانین اتاق ────────┐\n"
            "│ ۱. به همه احترام بگذار\n"
            "│ ۲. اسپم و فلود ممنوع\n"
            "│ ۳. آزار و اذیت ممنوع\n"
            "│ ۴. لذت ببر و دوست پیدا کن!\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, rules)

    async def show_languages(self, user: User) -> None:
        msg1 = (
            "┌─── 🌍 راهنمای ترجمه ──────┐\n"
            "│ فعال: !text [مبدا] [مقصد]\n"
            "│ غیرفعال: !stop\n"
            "│ مثال‌ها:\n"
            "│  !text fa en  (فارسی→انگلیسی)\n"
            "│  !text en fa  (انگلیسی→فارسی)\n"
            "│  !text ar fa  (عربی→فارسی)\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, msg1)
        await asyncio.sleep(0.5)

        msg2 = (
            "┌─── کدهای زبان ────────────┐\n"
            "│ fa  فارسی    en  انگلیسی\n"
            "│ ar  عربی     tr  ترکی\n"
            "│ ru  روسی     es  اسپانیایی\n"
            "│ fr  فرانسوی  de  آلمانی\n"
            "│ ja  ژاپنی    ko  کره‌ای\n"
            "│ zh  چینی     hi  هندی\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, msg2)

    async def show_emotes(self, user: User) -> None:
        msg1 = (
            "┌─── 🕺 امات‌های رقص ────────┐\n"
            "│ Anime  Casual  Ice  Jingle\n"
            "│ Kawaii KPop    Penguin Push\n"
            "│ Russian Shopping Thriller\n"
            "│ TikTok2/4/8/9/10/11 Touch\n"
            "│ Weird  Wrong   Punk  Guitar\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, msg1)
        await asyncio.sleep(0.5)

        msg2 = (
            "┌─── ✨ امات‌های دیگر ────────┐\n"
            "│ [پرواز] float flotar volar\n"
            "│          Zero  cohete\n"
            "│ [مبارزه] Boxer Espada HameHa\n"
            "│ [سرگرم]  Angel Bow  Cute UwU\n"
            "│           Hyped Snake Siuu\n"
            "│           Toilet Singing Paz\n"
            "└──────────────────────────┘"
        )
        await self.highrise.send_whisper(user.id, msg2)



# ════════════════════════════════════════════════════════════════════════════
# بخش ۵ — اجرای مستقیم (قبلاً run.py) — با «python main.py» ربات را روشن کن
# ════════════════════════════════════════════════════════════════════════════

def _run_forever() -> None:
    room_id = os.getenv("ROOM_ID")
    bot_token = os.getenv("BOT_TOKEN")

    if not room_id or not bot_token:
        print("خطا: ROOM_ID یا BOT_TOKEN در متغیرهای محیطی پیدا نشد.")
        print("یک فایل .env بساز با محتوای:\nROOM_ID=...\nBOT_TOKEN=...\nOWNER_ID=...")
        raise SystemExit(1)

    my_bot = BotDefinition(Bot(), room_id, bot_token)

    while True:
        try:
            arun(main([my_bot]))
        except Exception as e:
            print(f"خطای غیرمنتظره: {e}")
            print(traceback.format_exc())
            time.sleep(5)


if __name__ == "__main__":
    _run_forever()
