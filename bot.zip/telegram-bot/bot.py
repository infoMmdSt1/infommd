"""
Highrise Bot Creator — Telegram Bot (St1 HrBot Creator)
Main entry point.
"""
import os
import sys
import time
import shutil
import logging
import telebot
from telebot import types
from datetime import datetime

# Ensure local imports work when run from workspace root
sys.path.insert(0, os.path.dirname(__file__))

import config
import database as db
import bot_manager as bm

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MAIN] %(levelname)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("main")

bot = telebot.TeleBot(config.TELEGRAM_BOT_TOKEN, parse_mode="HTML")

# ─── State machine ────────────────────────────────────────────────────────────
# user_state[telegram_id] = {"step": str, "data": dict}
user_state: dict[int, dict] = {}

STEPS = {
    "WAIT_TOKEN":     "waiting for Highrise bot token",
    "WAIT_ROOM":      "waiting for room ID",
    "WAIT_OWNER":     "waiting for owner ID",
    "WAIT_NEW_TOKEN": "waiting for new token",
    "WAIT_NEW_ROOM":  "waiting for new room ID",
    "WAIT_NEW_OWNER": "waiting for new owner ID",
    "WAIT_BROADCAST": "waiting for broadcast message",
    "WAIT_BAN_ID":    "waiting for ban target",
    "WAIT_UNBAN_ID":  "waiting for unban target",
    "WAIT_VIP_ID":    "waiting for VIP target",
    "WAIT_UNVIP_ID":  "waiting for remove VIP target",
    "WAIT_SEARCH":    "waiting for search query",
    "WAIT_SUPPORT":   "waiting for support message",
    "WAIT_CHANNEL":   "waiting for channel ID",
}


def state(uid: int): return user_state.get(uid, {})
def set_state(uid: int, step: str, **data): user_state[uid] = {"step": step, "data": data}
def clear_state(uid: int): user_state.pop(uid, None)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def is_admin(uid: int) -> bool:
    return uid == config.ADMIN_ID


def require_user(fn):
    """Decorator: ensure user is in DB and not banned before calling handler."""
    def wrapper(message):
        uid = message.from_user.id
        u = db.get_user(uid)
        if u and u["is_banned"]:
            bot.send_message(uid, "🚫 <b>حساب شما مسدود شده است.</b>")
            return
        if not u:
            db.upsert_user(uid, message.from_user.username, message.from_user.first_name)
        return fn(message)
    return wrapper


def check_channel(uid: int) -> bool:
    """Returns True if the user has joined the required channel (or no channel set)."""
    ch = config.REQUIRED_CHANNEL or db.get_setting("required_channel", "")
    if not ch:
        return True
    try:
        member = bot.get_chat_member(ch, uid)
        return member.status not in ("left", "kicked")
    except Exception:
        return True  # if we can't check, let them through


def channel_join_keyboard() -> types.InlineKeyboardMarkup:
    ch = config.REQUIRED_CHANNEL or db.get_setting("required_channel", "")
    kb = types.InlineKeyboardMarkup()
    if ch:
        kb.add(types.InlineKeyboardButton("📢 عضویت در کانال", url=f"https://t.me/{ch.lstrip('@')}"))
    kb.add(types.InlineKeyboardButton("✅ عضو شدم", callback_data="check_join"))
    return kb


def main_keyboard(uid: int) -> types.ReplyKeyboardMarkup:
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("🤖 ربات‌های من", "➕ ساخت ربات جدید")
    kb.row("💎 پلن‌ها", "💬 پشتیبانی")
    kb.row("📊 وضعیت سرور")
    if is_admin(uid):
        kb.row("👑 پنل ادمین")
    return kb


def cancel_keyboard() -> types.ReplyKeyboardMarkup:
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("❌ لغو")
    return kb


def bot_list_keyboard(bots: list) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    for b in bots:
        status = "🟢" if bm.is_running(b["id"]) else "🔴"
        kb.add(types.InlineKeyboardButton(
            f"{status} {b['name']} — {b['room_id']}",
            callback_data=f"bot_panel:{b['id']}"
        ))
    return kb


def bot_panel_keyboard(bot_id: int, active: bool) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    if active:
        kb.add(
            types.InlineKeyboardButton("🔴 خاموش", callback_data=f"stop:{bot_id}"),
            types.InlineKeyboardButton("🔄 ری‌استارت", callback_data=f"restart:{bot_id}"),
        )
    else:
        kb.add(types.InlineKeyboardButton("🟢 روشن کردن", callback_data=f"start:{bot_id}"))
    kb.add(
        types.InlineKeyboardButton("⚙️ تنظیمات", callback_data=f"settings:{bot_id}"),
        types.InlineKeyboardButton("📊 وضعیت", callback_data=f"status:{bot_id}"),
    )
    kb.add(
        types.InlineKeyboardButton("📜 لاگ‌ها", callback_data=f"logs:{bot_id}"),
        types.InlineKeyboardButton("💬 پشتیبانی", callback_data=f"support:{bot_id}"),
    )
    kb.add(types.InlineKeyboardButton("🗑 حذف ربات", callback_data=f"delete_confirm:{bot_id}"))
    kb.add(types.InlineKeyboardButton("🔙 بازگشت", callback_data="my_bots"))
    return kb


def settings_keyboard(bot_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("🔑 تغییر توکن", callback_data=f"change_token:{bot_id}"),
        types.InlineKeyboardButton("🏠 تغییر Room ID", callback_data=f"change_room:{bot_id}"),
        types.InlineKeyboardButton("👤 تغییر Owner ID", callback_data=f"change_owner:{bot_id}"),
        types.InlineKeyboardButton("🔙 بازگشت", callback_data=f"bot_panel:{bot_id}"),
    )
    return kb


def admin_keyboard() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("📊 آمار", callback_data="admin_stats"),
        types.InlineKeyboardButton("📢 ارسال همگانی", callback_data="admin_broadcast"),
    )
    kb.add(
        types.InlineKeyboardButton("🚫 مسدود کاربر", callback_data="admin_ban"),
        types.InlineKeyboardButton("✅ رفع مسدودی", callback_data="admin_unban"),
    )
    kb.add(
        types.InlineKeyboardButton("💎 افزودن VIP", callback_data="admin_add_vip"),
        types.InlineKeyboardButton("💔 حذف VIP", callback_data="admin_remove_vip"),
    )
    kb.add(
        types.InlineKeyboardButton("🔍 جستجو ربات", callback_data="admin_search"),
        types.InlineKeyboardButton("📂 همه ربات‌ها", callback_data="admin_all_bots"),
    )
    kb.add(
        types.InlineKeyboardButton("💾 بکاپ دیتابیس", callback_data="admin_backup"),
        types.InlineKeyboardButton("📡 تنظیم کانال", callback_data="admin_channel"),
    )
    return kb


def format_bot_info(b: dict, uid: int) -> str:
    running = bm.is_running(b["id"])
    status = "🟢 آنلاین" if running else "🔴 آفلاین"
    uptime = bm.get_uptime(b["id"]) if running else "—"
    return (
        f"🤖 <b>{b['name']}</b>\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"📌 وضعیت: {status}\n"
        f"🏠 Room ID: <code>{b['room_id']}</code>\n"
        f"👑 Owner ID: <code>{b['owner_id']}</code>\n"
        f"⏱ Uptime: {uptime}\n"
        f"📅 ساخته شده: {b['created_at'][:10]}\n"
        f"📦 نسخه: {b['version']}\n"
        f"❤️ وضعیت سرور: ✅\n"
    )


def notify_user(bot_id: int, message: str):
    """Send a notification to the owner of a bot (used by bot_manager)."""
    b = db.get_bot(bot_id)
    if not b:
        return
    u = db.get_user(b["user_id"]) if False else None
    # get user telegram_id from user_id (DB id)
    import sqlite3
    conn = db.get_conn()
    row = conn.execute("SELECT telegram_id FROM users WHERE id=?", (b["user_id"],)).fetchone()
    conn.close()
    if row:
        try:
            bot.send_message(row["telegram_id"], message)
        except Exception:
            pass


# ─── /start ───────────────────────────────────────────────────────────────────

@bot.message_handler(commands=["start"])
def cmd_start(message):
    uid = message.from_user.id
    u = db.get_user(uid)
    if u and u["is_banned"]:
        bot.send_message(uid, "🚫 <b>حساب شما مسدود شده است.</b>")
        return

    db.upsert_user(uid, message.from_user.username, message.from_user.first_name)
    clear_state(uid)

    if not check_channel(uid):
        bot.send_message(uid,
            "📢 <b>برای استفاده از ربات ابتدا در کانال ما عضو شوید:</b>",
            reply_markup=channel_join_keyboard()
        )
        return

    name = message.from_user.first_name or "کاربر"
    vip = "💎 VIP" if (u and u["is_vip"]) else ""
    bot.send_message(uid,
        f"👋 سلام <b>{name}</b> {vip}!\n\n"
        f"🤖 <b>St1 HrBot Creator</b> — سیستم ساخت و مدیریت ربات‌های Highrise\n\n"
        f"با این ربات می‌تونی ربات‌های Highrise خودت رو بسازی و مدیریت کنی.\n\n"
        f"از منوی زیر گزینه موردنظرت رو انتخاب کن 👇",
        reply_markup=main_keyboard(uid)
    )


@bot.callback_query_handler(func=lambda c: c.data == "check_join")
def cb_check_join(call):
    uid = call.from_user.id
    if check_channel(uid):
        bot.answer_callback_query(call.id, "✅ عضویت تأیید شد!")
        bot.delete_message(uid, call.message.message_id)
        cmd_start(call.message)
    else:
        bot.answer_callback_query(call.id, "⚠️ هنوز عضو نشدید!", show_alert=True)


# ─── My Bots ──────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "🤖 ربات‌های من")
@require_user
def msg_my_bots(message):
    show_my_bots(message.from_user.id)


def show_my_bots(uid: int):
    u = db.get_user(uid)
    if not u:
        return
    bots = db.get_user_bots(u["id"])
    if not bots:
        bot.send_message(uid,
            "❌ شما هنوز هیچ ربات‌ی نساخته‌اید.\n\n"
            "روی <b>➕ ساخت ربات جدید</b> کلیک کنید.",
            reply_markup=main_keyboard(uid)
        )
        return

    bot.send_message(uid,
        f"🤖 <b>ربات‌های شما ({len(bots)} ربات):</b>\n\nیک ربات انتخاب کنید:",
        reply_markup=bot_list_keyboard(bots)
    )


@bot.callback_query_handler(func=lambda c: c.data == "my_bots")
def cb_my_bots(call):
    uid = call.from_user.id
    bot.answer_callback_query(call.id)
    show_my_bots(uid)


@bot.callback_query_handler(func=lambda c: c.data.startswith("bot_panel:"))
def cb_bot_panel(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    show_bot_panel(uid, bot_id, call.message.message_id)


def show_bot_panel(uid: int, bot_id: int, msg_id: int = None):
    b = db.get_bot(bot_id)
    if not b:
        bot.send_message(uid, "⚠️ ربات پیدا نشد.")
        return
    active = bm.is_running(bot_id)
    text = format_bot_info(b, uid)
    kb = bot_panel_keyboard(bot_id, active)
    if msg_id:
        try:
            bot.edit_message_text(text, uid, msg_id, reply_markup=kb)
        except Exception:
            bot.send_message(uid, text, reply_markup=kb)
    else:
        bot.send_message(uid, text, reply_markup=kb)


# ─── Create Bot ───────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "➕ ساخت ربات جدید")
@require_user
def msg_create_bot(message):
    uid = message.from_user.id
    if not check_channel(uid):
        bot.send_message(uid, "📢 ابتدا در کانال عضو شوید:", reply_markup=channel_join_keyboard())
        return

    u = db.get_user(uid)
    count = db.count_user_bots(u["id"])

    if not u["is_vip"] and count >= config.FREE_BOT_LIMIT:
        bot.send_message(uid,
            f"⚠️ <b>محدودیت پلن رایگان</b>\n\n"
            f"پلن رایگان فقط اجازه ساخت <b>{config.FREE_BOT_LIMIT} ربات</b> را می‌دهد.\n"
            f"برای ساخت ربات‌های بیشتر، پلن <b>💎 VIP</b> تهیه کنید.",
            reply_markup=main_keyboard(uid)
        )
        return

    set_state(uid, "WAIT_TOKEN")
    bot.send_message(uid,
        "🔐 <b>ساخت ربات جدید — مرحله ۱ از ۳</b>\n\n"
        "توکن ربات Highrise خود را ارسال کنید:\n\n"
        "<i>توکن را از پنل Highrise دریافت کنید.</i>",
        reply_markup=cancel_keyboard()
    )


# ─── Plans ────────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "💎 پلن‌ها")
@require_user
def msg_plans(message):
    uid = message.from_user.id
    u = db.get_user(uid)
    plan = "💎 VIP" if u and u["is_vip"] else "🆓 رایگان"
    bot.send_message(uid,
        f"💎 <b>سیستم پلن‌ها</b>\n\n"
        f"📌 پلن فعلی شما: <b>{plan}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"🆓 <b>پلن رایگان:</b>\n"
        f"• ساخت فقط ۱ ربات\n\n"
        f"⭐ <b>پلن VIP:</b>\n"
        f"• ساخت ربات‌های نامحدود\n"
        f"• اولویت اجرا روی سرور\n"
        f"• پشتیبانی ویژه ۲۴/۷\n"
        f"• دسترسی به امکانات اختصاصی\n\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"برای خرید VIP با پشتیبانی در تماس باشید 👇",
        reply_markup=main_keyboard(uid)
    )


# ─── Support ──────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "💬 پشتیبانی")
@require_user
def msg_support(message):
    uid = message.from_user.id
    set_state(uid, "WAIT_SUPPORT")
    bot.send_message(uid,
        "💬 <b>پشتیبانی</b>\n\n"
        "پیام خود را ارسال کنید. تیم پشتیبانی در اسرع وقت پاسخ می‌دهد.",
        reply_markup=cancel_keyboard()
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith("support:"))
def cb_support(call):
    uid = call.from_user.id
    bot.answer_callback_query(call.id)
    set_state(uid, "WAIT_SUPPORT")
    bot.send_message(uid,
        "💬 <b>پشتیبانی</b>\n\nپیام خود را ارسال کنید:",
        reply_markup=cancel_keyboard()
    )


# ─── Server Status ────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "📊 وضعیت سرور")
@require_user
def msg_server_status(message):
    uid = message.from_user.id
    active = db.count_active_bots()
    total = len(db.get_all_bots())
    users = db.count_users()
    bot.send_message(uid,
        f"📊 <b>وضعیت سرور</b>\n\n"
        f"❤️ وضعیت: ✅ آنلاین\n"
        f"🤖 ربات‌های فعال: <b>{active}</b>\n"
        f"🔴 ربات‌های خاموش: <b>{total - active}</b>\n"
        f"👥 کاربران: <b>{users}</b>\n"
        f"⏱ زمان سرور: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"📦 نسخه: <b>{config.BOT_VERSION}</b>",
        reply_markup=main_keyboard(uid)
    )


# ─── Bot Controls (inline callbacks) ─────────────────────────────────────────

@bot.callback_query_handler(func=lambda c: c.data.startswith("start:"))
def cb_start_bot(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    b = db.get_bot(bot_id)
    if not b:
        bot.answer_callback_query(call.id, "⚠️ ربات پیدا نشد.", show_alert=True)
        return
    if bm.is_running(bot_id):
        bot.answer_callback_query(call.id, "✅ ربات قبلاً روشن است.", show_alert=True)
        return
    bot.answer_callback_query(call.id, "🟢 در حال روشن کردن…")
    bm.start_bot(bot_id, b["token"], b["room_id"], b["owner_id"], notify_fn=notify_user)
    db.add_log(bot_id, "روشن شد توسط کاربر.", "INFO")
    bot.send_message(uid, f"🟢 <b>ربات روشن شد!</b>")
    show_bot_panel(uid, bot_id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("stop:"))
def cb_stop_bot(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id, "🔴 در حال خاموش کردن…")
    bm.stop_bot(bot_id)
    bot.send_message(uid, f"🔴 <b>ربات خاموش شد.</b>")
    show_bot_panel(uid, bot_id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("restart:"))
def cb_restart_bot(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    b = db.get_bot(bot_id)
    if not b:
        bot.answer_callback_query(call.id, "⚠️ ربات پیدا نشد.", show_alert=True)
        return
    bot.answer_callback_query(call.id, "🔄 در حال ری‌استارت…")
    bm.restart_bot(bot_id, b["token"], b["room_id"], b["owner_id"], notify_fn=notify_user)
    db.add_log(bot_id, "ری‌استارت توسط کاربر.", "INFO")
    bot.send_message(uid, f"🔄 <b>ربات ری‌استارت شد!</b>")
    show_bot_panel(uid, bot_id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("status:"))
def cb_status(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    b = db.get_bot(bot_id)
    if not b:
        bot.answer_callback_query(call.id)
        return
    bot.answer_callback_query(call.id)
    show_bot_panel(uid, bot_id, call.message.message_id)


@bot.callback_query_handler(func=lambda c: c.data.startswith("logs:"))
def cb_logs(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    logs = db.get_bot_logs(bot_id, limit=15)
    if not logs:
        bot.send_message(uid, "📜 هیچ لاگی یافت نشد.")
        return
    text = "📜 <b>آخرین لاگ‌ها:</b>\n\n"
    for l in reversed(logs):
        icon = "❌" if l["level"] == "ERROR" else ("⚠️" if l["level"] == "WARNING" else "ℹ️")
        text += f"{icon} <code>{l['created_at'][11:19]}</code> {l['message']}\n"
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton("🔙 بازگشت", callback_data=f"bot_panel:{bot_id}"))
    bot.send_message(uid, text, reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith("delete_confirm:"))
def cb_delete_confirm(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    b = db.get_bot(bot_id)
    if not b:
        return
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton("✅ بله، حذف شود", callback_data=f"delete_ok:{bot_id}"),
        types.InlineKeyboardButton("❌ خیر", callback_data=f"bot_panel:{bot_id}"),
    )
    bot.send_message(uid,
        f"⚠️ <b>آیا مطمئن هستید؟</b>\n\n"
        f"ربات <b>{b['name']}</b> حذف شود؟\n"
        f"این عمل قابل بازگشت نیست.",
        reply_markup=kb
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith("delete_ok:"))
def cb_delete_ok(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id, "🗑 در حال حذف…")
    bm.stop_bot(bot_id)
    db.delete_bot(bot_id)
    bot.send_message(uid, "✅ <b>ربات با موفقیت حذف شد.</b>", reply_markup=main_keyboard(uid))


# ─── Settings ─────────────────────────────────────────────────────────────────

@bot.callback_query_handler(func=lambda c: c.data.startswith("settings:"))
def cb_settings(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    b = db.get_bot(bot_id)
    if not b:
        return
    bot.send_message(uid,
        f"⚙️ <b>تنظیمات ربات {b['name']}</b>\n\nچه چیزی را می‌خواهید تغییر دهید؟",
        reply_markup=settings_keyboard(bot_id)
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith("change_token:"))
def cb_change_token(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    set_state(uid, "WAIT_NEW_TOKEN", bot_id=bot_id)
    bot.send_message(uid, "🔑 توکن جدید ربات Highrise را ارسال کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data.startswith("change_room:"))
def cb_change_room(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    set_state(uid, "WAIT_NEW_ROOM", bot_id=bot_id)
    bot.send_message(uid, "🏠 Room ID جدید را ارسال کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data.startswith("change_owner:"))
def cb_change_owner(call):
    uid = call.from_user.id
    bot_id = int(call.data.split(":")[1])
    bot.answer_callback_query(call.id)
    set_state(uid, "WAIT_NEW_OWNER", bot_id=bot_id)
    bot.send_message(uid, "👤 Owner ID جدید را ارسال کنید:", reply_markup=cancel_keyboard())


# ─── Admin Panel ──────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: m.text == "👑 پنل ادمین")
def msg_admin(message):
    uid = message.from_user.id
    if not is_admin(uid):
        bot.send_message(uid, "🚫 دسترسی غیرمجاز.")
        return
    bot.send_message(uid, "👑 <b>پنل مدیریت</b>\n\nیک گزینه انتخاب کنید:", reply_markup=admin_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_stats")
def cb_admin_stats(call):
    if not is_admin(call.from_user.id):
        bot.answer_callback_query(call.id, "🚫", show_alert=True)
        return
    bot.answer_callback_query(call.id)
    users = db.count_users()
    vip = db.count_vip()
    active = db.count_active_bots()
    inactive = db.count_inactive_bots()
    today = db.count_today_users()
    running = len(bm.get_all_running_ids())
    bot.send_message(call.from_user.id,
        f"📊 <b>آمار کلی</b>\n\n"
        f"👥 کل کاربران: <b>{users}</b>\n"
        f"💎 کاربران VIP: <b>{vip}</b>\n"
        f"📅 کاربران امروز: <b>{today}</b>\n\n"
        f"🤖 کل ربات‌ها: <b>{active + inactive}</b>\n"
        f"🟢 فعال: <b>{active}</b>\n"
        f"🔴 خاموش: <b>{inactive}</b>\n"
        f"⚡ در حال اجرا: <b>{running}</b>\n\n"
        f"⏱ {datetime.now().strftime('%Y-%m-%d %H:%M')}",
    )


@bot.callback_query_handler(func=lambda c: c.data == "admin_broadcast")
def cb_admin_broadcast(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_BROADCAST")
    bot.send_message(call.from_user.id, "📢 پیام همگانی را ارسال کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_ban")
def cb_admin_ban(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_BAN_ID")
    bot.send_message(call.from_user.id, "🚫 آیدی عددی کاربر موردنظر را ارسال کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_unban")
def cb_admin_unban(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_UNBAN_ID")
    bot.send_message(call.from_user.id, "✅ آیدی عددی کاربر موردنظر را ارسال کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_add_vip")
def cb_admin_add_vip(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_VIP_ID")
    bot.send_message(call.from_user.id, "💎 آیدی عددی کاربر را ارسال کنید تا VIP شود:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_remove_vip")
def cb_admin_remove_vip(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_UNVIP_ID")
    bot.send_message(call.from_user.id, "💔 آیدی عددی کاربر را ارسال کنید تا VIP حذف شود:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_search")
def cb_admin_search(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_SEARCH")
    bot.send_message(call.from_user.id, "🔍 Room ID یا Owner ID یا نام ربات را جستجو کنید:", reply_markup=cancel_keyboard())


@bot.callback_query_handler(func=lambda c: c.data == "admin_all_bots")
def cb_admin_all_bots(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    bots = db.get_all_bots()
    if not bots:
        bot.send_message(call.from_user.id, "هیچ ربات‌ی ثبت نشده.")
        return
    text = f"📂 <b>لیست تمام ربات‌ها ({len(bots)}):</b>\n\n"
    for b in bots[:30]:
        s = "🟢" if bm.is_running(b["id"]) else "🔴"
        text += f"{s} <b>{b['name']}</b> | @{b.get('username','?')} | Room: <code>{b['room_id']}</code>\n"
    bot.send_message(call.from_user.id, text)


@bot.callback_query_handler(func=lambda c: c.data == "admin_backup")
def cb_admin_backup(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id, "💾 در حال تهیه بکاپ…")
    backup_path = f"telegram-bot/data/backup_{int(time.time())}.db"
    try:
        shutil.copy(config.DB_PATH, backup_path)
        with open(backup_path, "rb") as f:
            bot.send_document(call.from_user.id, f, caption="💾 بکاپ دیتابیس")
        os.remove(backup_path)
    except Exception as e:
        bot.send_message(call.from_user.id, f"❌ خطا: {e}")


@bot.callback_query_handler(func=lambda c: c.data == "admin_channel")
def cb_admin_channel(call):
    if not is_admin(call.from_user.id):
        return
    bot.answer_callback_query(call.id)
    set_state(call.from_user.id, "WAIT_CHANNEL")
    current = config.REQUIRED_CHANNEL or db.get_setting("required_channel", "تنظیم نشده")
    bot.send_message(call.from_user.id,
        f"📡 <b>کانال اجباری</b>\n\nکانال فعلی: <code>{current}</code>\n\n"
        f"آیدی کانال جدید را وارد کنید (مثال: @mychannel)\n"
        f"برای غیرفعال کردن: <code>none</code> ارسال کنید.",
        reply_markup=cancel_keyboard()
    )


# ─── Admin controls on user bots ──────────────────────────────────────────────

def admin_bot_control_keyboard(bot_id: int) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    running = bm.is_running(bot_id)
    if running:
        kb.add(
            types.InlineKeyboardButton("🔴 خاموش", callback_data=f"adm_stop:{bot_id}"),
            types.InlineKeyboardButton("🔄 ری‌استارت", callback_data=f"adm_restart:{bot_id}"),
        )
    else:
        kb.add(types.InlineKeyboardButton("🟢 روشن", callback_data=f"adm_start:{bot_id}"))
    kb.add(types.InlineKeyboardButton("🗑 حذف", callback_data=f"adm_delete:{bot_id}"))
    return kb


@bot.callback_query_handler(func=lambda c: c.data.startswith("adm_start:"))
def cb_adm_start(call):
    if not is_admin(call.from_user.id):
        return
    bot_id = int(call.data.split(":")[1])
    b = db.get_bot(bot_id)
    if b:
        bm.start_bot(bot_id, b["token"], b["room_id"], b["owner_id"], notify_fn=notify_user)
        bot.answer_callback_query(call.id, "🟢 روشن شد")
    else:
        bot.answer_callback_query(call.id, "⚠️ پیدا نشد", show_alert=True)


@bot.callback_query_handler(func=lambda c: c.data.startswith("adm_stop:"))
def cb_adm_stop(call):
    if not is_admin(call.from_user.id):
        return
    bot_id = int(call.data.split(":")[1])
    bm.stop_bot(bot_id)
    bot.answer_callback_query(call.id, "🔴 خاموش شد")


@bot.callback_query_handler(func=lambda c: c.data.startswith("adm_restart:"))
def cb_adm_restart(call):
    if not is_admin(call.from_user.id):
        return
    bot_id = int(call.data.split(":")[1])
    b = db.get_bot(bot_id)
    if b:
        bm.restart_bot(bot_id, b["token"], b["room_id"], b["owner_id"], notify_fn=notify_user)
        bot.answer_callback_query(call.id, "🔄 ری‌استارت شد")


@bot.callback_query_handler(func=lambda c: c.data.startswith("adm_delete:"))
def cb_adm_delete(call):
    if not is_admin(call.from_user.id):
        return
    bot_id = int(call.data.split(":")[1])
    bm.stop_bot(bot_id)
    db.delete_bot(bot_id)
    bot.answer_callback_query(call.id, "🗑 حذف شد")
    bot.send_message(call.from_user.id, "✅ ربات حذف شد.")


# ─── State-driven text handler ────────────────────────────────────────────────

@bot.message_handler(func=lambda m: True)
@require_user
def handle_text(message):
    uid = message.from_user.id
    text = message.text or ""

    if text == "❌ لغو":
        clear_state(uid)
        bot.send_message(uid, "❌ عملیات لغو شد.", reply_markup=main_keyboard(uid))
        return

    st = state(uid)
    step = st.get("step")
    data = st.get("data", {})

    # ── Bot creation wizard ─────────────────────────────────
    if step == "WAIT_TOKEN":
        if len(text) < 10:
            bot.send_message(uid, "⚠️ توکن نامعتبر است. دوباره ارسال کنید.")
            return
        set_state(uid, "WAIT_ROOM", token=text)
        bot.send_message(uid,
            "🏠 <b>مرحله ۲ از ۳</b>\n\nRoom ID اتاق Highrise خود را ارسال کنید:\n\n"
            "<i>آیدی اتاقی که ربات باید در آن حضور داشته باشد.</i>",
        )
        return

    if step == "WAIT_ROOM":
        set_state(uid, "WAIT_OWNER", token=data.get("token"), room_id=text)
        bot.send_message(uid,
            "👑 <b>مرحله ۳ از ۳</b>\n\nOwner ID (آیدی مالک) را ارسال کنید:\n\n"
            "<i>آیدی اکانت Highrise صاحب ربات.</i>",
        )
        return

    if step == "WAIT_OWNER":
        token   = data.get("token")
        room_id = data.get("room_id")
        owner_id = text
        clear_state(uid)

        u = db.get_user(uid)
        bot_id = db.create_bot(u["id"], token, room_id, owner_id)
        db.add_log(bot_id, "ربات ساخته شد.", "INFO")

        bot.send_message(uid,
            f"✅ <b>ربات با موفقیت ساخته شد!</b>\n\n"
            f"🏠 Room ID: <code>{room_id}</code>\n"
            f"👑 Owner ID: <code>{owner_id}</code>\n\n"
            f"برای روشن کردن ربات، از منوی <b>🤖 ربات‌های من</b> اقدام کنید.",
            reply_markup=main_keyboard(uid)
        )

        # Auto-start
        bm.start_bot(bot_id, token, room_id, owner_id, notify_fn=notify_user)
        db.set_bot_active(bot_id, True)
        bot.send_message(uid, "🟢 <b>ربات شما روشن شد!</b>")
        return

    # ── Settings changes ────────────────────────────────────
    if step == "WAIT_NEW_TOKEN":
        bot_id = data.get("bot_id")
        clear_state(uid)
        db.update_bot_field(bot_id, "token", text)
        b = db.get_bot(bot_id)
        if b and bm.is_running(bot_id):
            bm.restart_bot(bot_id, text, b["room_id"], b["owner_id"], notify_fn=notify_user)
        db.add_log(bot_id, "توکن تغییر کرد.", "INFO")
        bot.send_message(uid, "✅ توکن با موفقیت تغییر کرد.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_NEW_ROOM":
        bot_id = data.get("bot_id")
        clear_state(uid)
        db.update_bot_field(bot_id, "room_id", text)
        b = db.get_bot(bot_id)
        if b and bm.is_running(bot_id):
            bm.restart_bot(bot_id, b["token"], text, b["owner_id"], notify_fn=notify_user)
        db.add_log(bot_id, f"Room ID تغییر کرد به {text}.", "INFO")
        bot.send_message(uid, "✅ Room ID با موفقیت تغییر کرد.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_NEW_OWNER":
        bot_id = data.get("bot_id")
        clear_state(uid)
        db.update_bot_field(bot_id, "owner_id", text)
        db.add_log(bot_id, f"Owner ID تغییر کرد.", "INFO")
        bot.send_message(uid, "✅ Owner ID با موفقیت تغییر کرد.", reply_markup=main_keyboard(uid))
        return

    # ── Support ─────────────────────────────────────────────
    if step == "WAIT_SUPPORT":
        clear_state(uid)
        u = db.get_user(uid)
        admin_msg = (
            f"💬 <b>پیام پشتیبانی</b>\n\n"
            f"👤 کاربر: @{message.from_user.username or '—'} (<code>{uid}</code>)\n"
            f"💎 VIP: {'✅' if u and u['is_vip'] else '❌'}\n\n"
            f"📝 پیام:\n{text}"
        )
        try:
            kb = types.InlineKeyboardMarkup()
            kb.add(types.InlineKeyboardButton("↩️ پاسخ", callback_data=f"reply_support:{uid}"))
            bot.send_message(config.ADMIN_ID, admin_msg, reply_markup=kb)
        except Exception:
            pass
        bot.send_message(uid, "✅ پیام شما ارسال شد. به زودی پاسخ می‌گیرید.", reply_markup=main_keyboard(uid))
        return

    # ── Admin workflows ─────────────────────────────────────
    if step == "WAIT_BROADCAST" and is_admin(uid):
        clear_state(uid)
        users = db.get_all_users()
        sent = failed = 0
        for u in users:
            try:
                bot.send_message(u["telegram_id"], f"📢 <b>پیام مدیریت:</b>\n\n{text}")
                sent += 1
            except Exception:
                failed += 1
        bot.send_message(uid, f"📢 پیام همگانی ارسال شد.\n✅ موفق: {sent}\n❌ ناموفق: {failed}", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_BAN_ID" and is_admin(uid):
        clear_state(uid)
        try:
            target = int(text)
            db.set_banned(target, True)
            bot.send_message(uid, f"🚫 کاربر <code>{target}</code> مسدود شد.", reply_markup=main_keyboard(uid))
            try:
                bot.send_message(target, "🚫 حساب شما توسط مدیریت مسدود شد.")
            except Exception:
                pass
        except ValueError:
            bot.send_message(uid, "⚠️ آیدی نامعتبر است.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_UNBAN_ID" and is_admin(uid):
        clear_state(uid)
        try:
            target = int(text)
            db.set_banned(target, False)
            bot.send_message(uid, f"✅ مسدودی کاربر <code>{target}</code> رفع شد.", reply_markup=main_keyboard(uid))
        except ValueError:
            bot.send_message(uid, "⚠️ آیدی نامعتبر است.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_VIP_ID" and is_admin(uid):
        clear_state(uid)
        try:
            target = int(text)
            db.set_vip(target, True)
            bot.send_message(uid, f"💎 کاربر <code>{target}</code> به VIP ارتقا یافت.", reply_markup=main_keyboard(uid))
            try:
                bot.send_message(target, "💎 <b>تبریک! حساب شما به پلن VIP ارتقا یافت.</b>")
            except Exception:
                pass
        except ValueError:
            bot.send_message(uid, "⚠️ آیدی نامعتبر است.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_UNVIP_ID" and is_admin(uid):
        clear_state(uid)
        try:
            target = int(text)
            db.set_vip(target, False)
            bot.send_message(uid, f"💔 VIP کاربر <code>{target}</code> حذف شد.", reply_markup=main_keyboard(uid))
        except ValueError:
            bot.send_message(uid, "⚠️ آیدی نامعتبر است.", reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_SEARCH" and is_admin(uid):
        clear_state(uid)
        results = db.search_bots(text)
        if not results:
            bot.send_message(uid, "🔍 نتیجه‌ای یافت نشد.", reply_markup=main_keyboard(uid))
            return
        msg = f"🔍 <b>نتایج جستجو ({len(results)}):</b>\n\n"
        for b in results:
            s = "🟢" if bm.is_running(b["id"]) else "🔴"
            msg += (
                f"{s} <b>{b['name']}</b>\n"
                f"   👤 @{b.get('username','?')} | 🏠 <code>{b['room_id']}</code>\n\n"
            )
        bot.send_message(uid, msg, reply_markup=main_keyboard(uid))
        return

    if step == "WAIT_CHANNEL" and is_admin(uid):
        clear_state(uid)
        val = text.strip()
        if val.lower() == "none":
            db.set_setting("required_channel", "")
            bot.send_message(uid, "✅ کانال اجباری غیرفعال شد.", reply_markup=main_keyboard(uid))
        else:
            db.set_setting("required_channel", val)
            bot.send_message(uid, f"✅ کانال اجباری تنظیم شد: <code>{val}</code>", reply_markup=main_keyboard(uid))
        return

    # ── Fallback ────────────────────────────────────────────
    bot.send_message(uid,
        "❓ دستور نامشخص. از منوی زیر استفاده کنید:",
        reply_markup=main_keyboard(uid)
    )


# ─── Admin /admin command ──────────────────────────────────────────────────────

@bot.message_handler(commands=["admin"])
def cmd_admin(message):
    if not is_admin(message.from_user.id):
        bot.send_message(message.from_user.id, "🚫 دسترسی غیرمجاز.")
        return
    msg_admin(message)


@bot.message_handler(commands=["stats"])
def cmd_stats(message):
    if not is_admin(message.from_user.id):
        return
    users = db.count_users()
    vip = db.count_vip()
    active = db.count_active_bots()
    inactive = db.count_inactive_bots()
    bot.send_message(message.from_user.id,
        f"📊 <b>آمار:</b>\n👥 {users} کاربر | 💎 {vip} VIP\n🟢 {active} فعال | 🔴 {inactive} خاموش"
    )


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    db.init_db()
    log.info(f"🤖 St1 HrBot Creator v{config.BOT_VERSION} starting…")
    log.info(f"   Admin ID: {config.ADMIN_ID}")
    log.info(f"   Required channel: {config.REQUIRED_CHANNEL or '(none)'}")

    import os as _os
    _os.makedirs("telegram-bot/logs", exist_ok=True)
    _os.makedirs("telegram-bot/data", exist_ok=True)

    bot.infinity_polling(timeout=60, long_polling_timeout=60)
