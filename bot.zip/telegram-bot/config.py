import os

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8829289939:AAEtsQVp8pT66iU0eiuy6I8Zhg37TzgInJI")
ADMIN_ID = int(os.environ.get("ADMIN_TELEGRAM_ID", "8181942735"))
REQUIRED_CHANNEL = os.environ.get("REQUIRED_CHANNEL", "NexValHr")  # e.g. @mychannel or -100xxx

DB_PATH = "telegram-bot/data/hrbot.db"
LOG_DIR = "telegram-bot/logs"
BOT_VERSION = "1.0.0"

FREE_BOT_LIMIT = 1
