"""Manages Highrise bot subprocess lifecycle using the real main.py source."""
import subprocess
import os
import sys
import time
import shutil
import threading
from pathlib import Path
from database import set_bot_active, add_log

LOG_DIR = Path("telegram-bot/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)

# Absolute path to the real Highrise bot source
HRBOT_SOURCE = Path("telegram-bot/highrise_source/main.py").resolve()

# Each user bot gets its own isolated working dir: telegram-bot/bots/<bot_id>/
BOTS_DIR = Path("telegram-bot/bots")
BOTS_DIR.mkdir(parents=True, exist_ok=True)

# bot_id -> {"process": Popen, "start_time": float, "args": list, "env": dict}
_running: dict[int, dict] = {}
_lock = threading.Lock()


def _bot_dir(bot_id: int) -> Path:
    d = BOTS_DIR / str(bot_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _prepare_bot_dir(bot_id: int, token: str, room_id: str, owner_id: str) -> Path:
    """Copy main.py into the bot's own directory and write its .env file."""
    d = _bot_dir(bot_id)
    # Copy (or overwrite) the bot source
    shutil.copy(HRBOT_SOURCE, d / "main.py")
    # Write .env so main.py picks it up via load_dotenv()
    env_content = (
        f"ROOM_ID={room_id}\n"
        f"BOT_TOKEN={token}\n"
        f"OWNER_ID={owner_id}\n"
    )
    (d / ".env").write_text(env_content, encoding="utf-8")
    return d


def _spawn(bot_id: int, bot_dir: Path) -> subprocess.Popen:
    log_file = LOG_DIR / f"bot_{bot_id}.log"
    log_fp = open(log_file, "a", encoding="utf-8")
    env = os.environ.copy()
    process = subprocess.Popen(
        [sys.executable, "main.py"],
        cwd=str(bot_dir),
        stdout=log_fp,
        stderr=log_fp,
        env=env,
    )
    return process


def _monitor(bot_id: int, process: subprocess.Popen, bot_dir: Path, notify_fn=None):
    """Watch the process; auto-restart on crash."""
    while True:
        process.wait()
        rc = process.returncode

        with _lock:
            if bot_id not in _running:
                break  # manually stopped
            entry = _running.get(bot_id)
            if entry and entry["process"] is not process:
                break  # replaced by restart

        add_log(bot_id, f"پروسه ربات خاتمه یافت (کد {rc}). ری‌استارت خودکار…", "WARNING")
        set_bot_active(bot_id, False)
        time.sleep(5)

        with _lock:
            if bot_id not in _running:
                break

        process = _spawn(bot_id, bot_dir)
        with _lock:
            if bot_id in _running:
                _running[bot_id]["process"] = process
                _running[bot_id]["start_time"] = time.time()
        set_bot_active(bot_id, True)
        add_log(bot_id, "ری‌استارت خودکار بعد از کرش.", "INFO")
        if notify_fn:
            try:
                notify_fn(bot_id, "♻️ ربات بعد از کرش به‌صورت خودکار ری‌استارت شد.")
            except Exception:
                pass


def start_bot(bot_id: int, token: str, room_id: str, owner_id: str, notify_fn=None) -> bool:
    with _lock:
        if bot_id in _running:
            return False

    bot_dir = _prepare_bot_dir(bot_id, token, room_id, owner_id)
    process = _spawn(bot_id, bot_dir)

    with _lock:
        _running[bot_id] = {
            "process": process,
            "start_time": time.time(),
            "bot_dir": bot_dir,
        }

    t = threading.Thread(target=_monitor, args=(bot_id, process, bot_dir, notify_fn), daemon=True)
    t.start()

    set_bot_active(bot_id, True)
    add_log(bot_id, "ربات روشن شد.", "INFO")
    return True


def stop_bot(bot_id: int) -> bool:
    with _lock:
        entry = _running.pop(bot_id, None)

    if not entry:
        return False

    process: subprocess.Popen = entry["process"]
    try:
        process.terminate()
        process.wait(timeout=10)
    except Exception:
        try:
            process.kill()
        except Exception:
            pass

    set_bot_active(bot_id, False)
    add_log(bot_id, "ربات توسط کاربر خاموش شد.", "INFO")
    return True


def restart_bot(bot_id: int, token: str, room_id: str, owner_id: str, notify_fn=None) -> bool:
    stop_bot(bot_id)
    time.sleep(1)
    return start_bot(bot_id, token, room_id, owner_id, notify_fn)


def update_bot_credentials(bot_id: int, token: str, room_id: str, owner_id: str):
    """Rewrite the .env file (used when settings change)."""
    d = _bot_dir(bot_id)
    if (d / "main.py").exists():
        env_content = (
            f"ROOM_ID={room_id}\n"
            f"BOT_TOKEN={token}\n"
            f"OWNER_ID={owner_id}\n"
        )
        (d / ".env").write_text(env_content, encoding="utf-8")


def is_running(bot_id: int) -> bool:
    with _lock:
        return bot_id in _running


def get_uptime(bot_id: int) -> str:
    with _lock:
        entry = _running.get(bot_id)
    if not entry:
        return "آفلاین"
    elapsed = int(time.time() - entry["start_time"])
    h, r = divmod(elapsed, 3600)
    m, s = divmod(r, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


def get_all_running_ids() -> list[int]:
    with _lock:
        return list(_running.keys())
