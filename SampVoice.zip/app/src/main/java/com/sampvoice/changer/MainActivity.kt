package com.sampvoice.changer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFF0F0B1F.toInt())
        }

        col.addView(TextView(this).apply {
            text = "VC PRO"
            textSize = 30f
            setTextColor(0xFFA855F7.toInt())
            typeface = android.graphics.Typeface.defaultFromStyle(android.graphics.Typeface.BOLD_ITALIC)
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "تغییر صدای حرفه‌ای در بازی‌های اندروید"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })

        col.addView(TextView(this).apply {
            text = "دکمه زیر رو بزن تا منوی شناور روی صفحه بیاد. " +
                "روی منوی کوچک بزن تا باز بشه، با ✕ ببندش، و با کشیدن جابجاش کن. " +
                "از منو میتونی صدا رو بم، کلفت، نازک کنی، نویز بندازی و بلندیش رو کم و زیاد کنی."
            textSize = 14f
            setTextColor(0xFFCBD5E1.toInt())
            setPadding(0, pad, 0, pad)
        })

        col.addView(Button(this).apply {
            text = "فعال‌سازی منو"
            setOnClickListener { begin() }
        })
        col.addView(Button(this).apply {
            text = "بستن منو و توقف"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                status.text = "منو بسته شد."
            }
        })

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFC4B5FD.toInt())
            setPadding(0, pad, 0, 0)
        }
        col.addView(status)

        setContentView(col)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "اجازه «نمایش روی سایر برنامه‌ها» رو روشن کن و برگرد، بعد دوباره دکمه رو بزن."
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val needed = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 100)
            return
        }
        launchOverlay()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchOverlay()
        } else {
            status.text = "بدون اجازه میکروفون کار نمیکنه."
        }
    }

    private fun launchOverlay() {
        startForegroundService(Intent(this, OverlayService::class.java))
        status.text = "منو فعاله. بازی سمپ رو باز کن؛ منوی کوچک روی صفحه هست."
    }
}
