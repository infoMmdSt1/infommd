package com.sampvoice.changer

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/** فیلتر shelf (بم/زیر) به روش RBJ */
class Biquad {
    private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
    private var a1 = 0.0; private var a2 = 0.0
    private var z1 = 0.0; private var z2 = 0.0

    private fun set(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0
        a1 = na1 / a0; a2 = na2 / a0
    }

    fun lowShelf(fs: Double, f0: Double, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs
        val c = cos(w0)
        val alpha = sin(w0) / 2.0 * sqrt(2.0)
        val beta = 2 * sqrt(a) * alpha
        set(
            a * ((a + 1) - (a - 1) * c + beta),
            2 * a * ((a - 1) - (a + 1) * c),
            a * ((a + 1) - (a - 1) * c - beta),
            (a + 1) + (a - 1) * c + beta,
            -2 * ((a - 1) + (a + 1) * c),
            (a + 1) + (a - 1) * c - beta
        )
    }

    fun highShelf(fs: Double, f0: Double, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs
        val c = cos(w0)
        val alpha = sin(w0) / 2.0 * sqrt(2.0)
        val beta = 2 * sqrt(a) * alpha
        set(
            a * ((a + 1) + (a - 1) * c + beta),
            -2 * a * ((a - 1) + (a + 1) * c),
            a * ((a + 1) + (a - 1) * c - beta),
            (a + 1) - (a - 1) * c + beta,
            2 * ((a - 1) - (a + 1) * c),
            (a + 1) - (a - 1) * c - beta
        )
    }

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + z1
        z1 = b1 * xd - a1 * y + z2
        z2 = b2 * xd - a2 * y
        return y.toFloat()
    }
}

/** تغییر پیچ به روش دو خط تأخیر متحرک با کراس‌فید (real-time) */
class PitchShifter(private val windowSize: Int = 2048) {
    private val size = windowSize * 4
    private val buf = FloatArray(size)
    private var w = 0
    private var pos = 0.0

    private fun hann(p: Double) = (0.5 - 0.5 * cos(2 * PI * p)).toFloat()

    private fun read(delay: Double): Float {
        var r = w - delay
        while (r < 0) r += size
        val i0 = r.toInt() % size
        val i1 = (i0 + 1) % size
        val f = (r - r.toInt()).toFloat()
        return buf[i0] * (1 - f) + buf[i1] * f
    }

    fun process(x: Float, ratio: Double): Float {
        buf[w] = x
        val out: Float
        if (kotlin.math.abs(ratio - 1.0) < 0.001) {
            out = x
        } else {
            val p2 = (pos + 0.5) % 1.0
            out = read(pos * windowSize) * hann(pos) + read(p2 * windowSize) * hann(p2)
            pos += (1.0 - ratio) / windowSize
            while (pos < 0) pos += 1.0
            while (pos >= 1.0) pos -= 1.0
        }
        w = (w + 1) % size
        return out
    }
}

class VoiceEngine {
    @Volatile var pitchSemitones = 0f      // -12 .. +12
    @Volatile var bassDb = 0f              // بم کردن / کلفت کردن
    @Volatile var trebleDb = 0f            // نازک کردن
    @Volatile var noise = 0f               // 0 .. 1
    @Volatile var volume = 1f              // 0 .. 4

    @Volatile private var running = false
    private var thread: Thread? = null

    @Volatile private var capture: ShortArray? = null
    private var capturePos = 0
    @Volatile var onCaptureDone: ((ShortArray) -> Unit)? = null

    val isRunning: Boolean get() = running

    /** ضبط چند ثانیه از صدای پردازش‌شده برای «پخش تست» */
    fun captureTest(seconds: Int): Boolean {
        if (!running) return false
        capturePos = 0
        capture = ShortArray(SAMPLE_RATE * seconds)
        return true
    }

    companion object {
        const val SAMPLE_RATE = 44100
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        val sr = SAMPLE_RATE
        val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) return false

        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, sr,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minIn, 4096)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sr)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minOut, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()

        running = true
        thread = Thread {
            val shifter = PitchShifter()
            val low = Biquad()
            val high = Biquad()
            val rnd = Random()
            var lastBass = Float.NaN
            var lastTreble = Float.NaN
            val inBuf = ShortArray(512)
            val outBuf = ShortArray(512)

            rec.startRecording()
            track.play()
            while (running) {
                val n = rec.read(inBuf, 0, inBuf.size)
                if (n <= 0) continue

                val bass = bassDb
                val treble = trebleDb
                if (bass != lastBass) { low.lowShelf(sr.toDouble(), 200.0, bass.toDouble()); lastBass = bass }
                if (treble != lastTreble) { high.highShelf(sr.toDouble(), 3000.0, treble.toDouble()); lastTreble = treble }

                val ratio = 2.0.pow(pitchSemitones / 12.0)
                val nz = noise * 0.15f
                val vol = volume

                for (i in 0 until n) {
                    var x = inBuf[i] / 32768f
                    x = shifter.process(x, ratio)
                    x = low.process(x)
                    x = high.process(x)
                    if (nz > 0f) x += (rnd.nextFloat() * 2f - 1f) * nz
                    x = tanh(x * vol)
                    outBuf[i] = (x * 32767f).toInt().toShort()
                }
                val c = capture
                if (c != null) {
                    val k = minOf(n, c.size - capturePos)
                    System.arraycopy(outBuf, 0, c, capturePos, k)
                    capturePos += k
                    if (capturePos >= c.size) {
                        capture = null
                        onCaptureDone?.invoke(c)
                    }
                }
                track.write(outBuf, 0, n)
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }.also { it.start() }
        return true
    }

    fun stop() {
        running = false
        try { thread?.join(500) } catch (_: Exception) {}
        thread = null
    }
}
