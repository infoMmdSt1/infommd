package com.sampvoice.changer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** آیکون میکروفون که با Canvas کشیده میشه */
class MicView(ctx: Context, private val color: Int = 0xFFA855F7.toInt()) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@MicView.color; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@MicView.color; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        line.strokeWidth = w * 0.08f
        c.drawRoundRect(RectF(w * .34f, h * .06f, w * .66f, h * .56f), w * .16f, w * .16f, fill)
        c.drawArc(RectF(w * .20f, h * .26f, w * .80f, h * .72f), 0f, 180f, false, line)
        c.drawLine(w * .5f, h * .72f, w * .5f, h * .90f, line)
        c.drawLine(w * .36f, h * .90f, w * .64f, h * .90f, line)
    }
}

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var pill: LinearLayout
    private lateinit var panel: LinearLayout
    private val engine = VoiceEngine()
    private val main = Handler(Looper.getMainLooper())
    private var expanded = false

    // وضعیت
    private var mode = 0            // 0 عادی، 1 کلفت، 2 بم، 3 نازک
    private var noiseIdx = 0
    private var volPct = 100

    private val noiseLevels = intArrayOf(0, 20, 40, 70)

    private lateinit var btnThick: LinearLayout
    private lateinit var btnDeep: LinearLayout
    private lateinit var btnThin: LinearLayout
    private lateinit var btnNoise: LinearLayout
    private lateinit var noiseLabel: TextView
    private lateinit var powerLabel: TextView
    private lateinit var seek: SeekBar
    private lateinit var volText: TextView

    private val purple = 0xFF8B5CF6.toInt()
    private val panelBg = 0xF20F0B1F.toInt()
    private val btnBg = 0xFF1A1432.toInt()
    private val btnActive = 0xFF4C1D95.toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (root == null) {
            buildOverlay()
            if (!engine.start()) {
                Toast.makeText(this, "میکروفون در دسترس نیست", Toast.LENGTH_SHORT).show()
            }
            applyState()
            updatePower()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        engine.stop()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Voice changer", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VC PRO فعاله")
            .setContentText("برای بستن کامل منو بزن روی «بستن»")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "بستن", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- کمک‌ها ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int = 1) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp), stroke)
    }

    private fun text(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun gridButton(icon: String, iconColor: Int, label: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = bg(btnBg, 0xFF4C3A8A.toInt(), 10)
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            addView(text(label, 12f, Color.WHITE, true))
            addView(text(icon, 15f, iconColor).apply { setPadding(dp(6), 0, 0, 0) })
            setOnClickListener { onClick() }
        }

    private fun setActive(btn: LinearLayout, on: Boolean) {
        btn.background = if (on) bg(btnActive, purple, 10, 2) else bg(btnBg, 0xFF4C3A8A.toInt(), 10)
    }

    private fun rowOf(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        v.forEach { addView(it) }
    }

    // ---------- ساخت منو ----------
    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // حالت کوچک: میکروفون + فلش
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = bg(panelBg, purple, 12, 2)
            setPadding(dp(12), dp(8), dp(10), dp(8))
            addView(MicView(this@OverlayService).apply { layoutParams = LinearLayout.LayoutParams(dp(26), dp(30)) })
            addView(text("▾", 18f, Color.WHITE).apply { setPadding(dp(8), 0, 0, 0) })
        }

        // حالت بزرگ
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(panelBg, purple, 16, 2)
            setPadding(dp(10), dp(8), dp(10), dp(10))
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(310), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        buildPanel()

        r.addView(pill)
        r.addView(panel)
        root = r

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(16)
            y = dp(90)
        }

        attachDrag(pill) { setExpanded(true) }
        wm.addView(r, params)
    }

    private fun setExpanded(on: Boolean) {
        expanded = on
        panel.visibility = if (on) View.VISIBLE else View.GONE
        pill.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun buildPanel() {
        // هدر: میکروفون، VC PRO، بستن
        val close = text("✕", 18f, Color.WHITE).apply {
            setPadding(dp(10), dp(2), dp(4), dp(2))
            setOnClickListener { setExpanded(false) }
        }
        val title = text("VC PRO", 17f, 0xFFC4B5FD.toInt()).apply {
            typeface = Typeface.defaultFromStyle(Typeface.BOLD_ITALIC)
            setPadding(dp(8), 0, 0, 0)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(MicView(this@OverlayService).apply { layoutParams = LinearLayout.LayoutParams(dp(24), dp(28)) })
            addView(title)
            addView(View(this@OverlayService).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
            addView(close)
        }
        attachDrag(header, null)
        panel.addView(header)

        // ردیف ۱: کلفت | بم   (در RTL اولی سمت راسته)
        btnThick = gridButton("💪", 0xFFFBBF24.toInt(), "صدای کلفت") { setMode(1) }
        btnDeep = gridButton("♂", 0xFF38BDF8.toInt(), "صدای بم") { setMode(2) }
        panel.addView(rowOf(btnThick, btnDeep))

        // ردیف ۲: نویز | نازک
        btnNoise = gridButton("〰", 0xFFA855F7.toInt(), "نویز صدا") { cycleNoise() }
        noiseLabel = (btnNoise.getChildAt(0) as TextView)
        btnThin = gridButton("♀", 0xFFF472B6.toInt(), "صدای نازک") { setMode(3) }
        panel.addView(rowOf(btnNoise, btnThin))

        // ردیف ۳: کاهش | افزایش
        val down = gridButton("🔉", 0xFF93C5FD.toInt(), "کاهش صدا") { changeVol(-25) }
        val up = gridButton("🔊", 0xFF60A5FA.toInt(), "افزایش صدا") { changeVol(25) }
        panel.addView(rowOf(down, up))

        // اسلایدر بلندی (چپ به راست)
        seek = SeekBar(this).apply {
            max = 400
            progress = volPct
            progressTintList = ColorStateList.valueOf(purple)
            thumbTintList = ColorStateList.valueOf(0xFFC4B5FD.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        volText = text("100%", 13f)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { volPct = p; applyState() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val volRow = rowOf(text("🔊", 15f), seek, volText).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        panel.addView(volRow)

        // ردیف پایین: غیرفعال کردن | ریست | پخش تست
        val power = gridButton("⏻", 0xFFF472B6.toInt(), "غیرفعال کردن") { togglePower() }
        powerLabel = (power.getChildAt(0) as TextView)
        val reset = gridButton("⟳", 0xFFC4B5FD.toInt(), "ریست") { resetAll() }
        val test = gridButton("▶", 0xFFA855F7.toInt(), "پخش تست") { playTestClicked() }
        panel.addView(rowOf(power, reset, test))
    }

    // ---------- جابجایی با کشیدن ----------
    private fun attachDrag(v: View, onTap: (() -> Unit)?) {
        v.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            wm.updateViewLayout(root, params)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
                }
                return true
            }
        })
    }

    // ---------- منطق ----------
    private fun setMode(m: Int) {
        mode = if (mode == m) 0 else m
        applyState()
    }

    private fun cycleNoise() {
        noiseIdx = (noiseIdx + 1) % noiseLevels.size
        applyState()
    }

    private fun changeVol(delta: Int) {
        volPct = (volPct + delta).coerceIn(0, 400)
        applyState()
    }

    private fun resetAll() {
        mode = 0; noiseIdx = 0; volPct = 100
        applyState()
    }

    private fun applyState() {
        when (mode) {
            1 -> { engine.pitchSemitones = -3f; engine.bassDb = 12f; engine.trebleDb = 0f }
            2 -> { engine.pitchSemitones = -5f; engine.bassDb = 10f; engine.trebleDb = -4f }
            3 -> { engine.pitchSemitones = 5f; engine.bassDb = -8f; engine.trebleDb = 8f }
            else -> { engine.pitchSemitones = 0f; engine.bassDb = 0f; engine.trebleDb = 0f }
        }
        engine.noise = noiseLevels[noiseIdx] / 100f
        engine.volume = volPct / 100f

        setActive(btnThick, mode == 1)
        setActive(btnDeep, mode == 2)
        setActive(btnThin, mode == 3)
        setActive(btnNoise, noiseIdx > 0)
        noiseLabel.text = if (noiseIdx > 0) "نویز ${noiseLevels[noiseIdx]}%" else "نویز صدا"
        if (seek.progress != volPct) seek.progress = volPct
        volText.text = "$volPct%"
    }

    private fun togglePower() {
        if (engine.isRunning) {
            engine.stop()
        } else if (!engine.start()) {
            Toast.makeText(this, "میکروفون در دسترس نیست", Toast.LENGTH_SHORT).show()
        }
        updatePower()
    }

    private fun updatePower() {
        powerLabel.text = if (engine.isRunning) "غیرفعال کردن" else "فعال کردن"
    }

    private fun playTestClicked() {
        engine.onCaptureDone = { data -> main.post { playBack(data) } }
        if (engine.captureTest(3)) {
            Toast.makeText(this, "۳ ثانیه حرف بزن...", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "اول تغییر صدا رو فعال کن", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playBack(data: ShortArray) {
        Thread {
            try {
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setSampleRate(VoiceEngine.SAMPLE_RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.play()
                Thread.sleep(3200)
                t.release()
            } catch (_: Exception) {
            }
        }.start()
    }

    companion object {
        const val ACTION_STOP = "com.sampvoice.changer.STOP"
        private const val CHANNEL = "voice_changer"
    }
}
